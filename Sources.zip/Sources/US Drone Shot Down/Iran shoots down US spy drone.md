# Iran shoots down US spy drone

> Tehran, June 20, IRNA – The Islamic Revolution Guard Corps (IRGC) declared on Thursday that it has shot down a US spy drone.

Tehran, June 20, IRNA – The Islamic Revolution Guard Corps (IRGC) declared on Thursday that it has shot down a US spy drone.

At the early hours of Thursday, the IRGC air force shot down an American spy drone, identified as RQ-4 Global Hawk that had violated Iranian airspace in the Kuh Mubarak region located at Hormozgan province, south of the country, the IRGC’s public relations department said in a statement.

RQ-4s typically fly at high altitude to conduct reconnaissance missions.

Tensions among Iran and the US increased following US breach of the nuclear deal and re-imposing wrongful sanctions in total disregard of the UN Security Council Resolution 2231.

9191\*\*1416

Follow us on Twitter [@IrnaEnglish](http://twitter.com/irnaenglish)


[Source](https://en.irna.ir/news/83362061/Iran-shoots-down-US-spy-drone)