# Strait of Hormuz: US confirms drone shot down by Iran

> It happened over the Strait of Hormuz, amid soaring tensions between the US and Iran.

![A handout photo made available by the US Navy provided by Northrop Grumman, a RQ-4 Global Hawk unmanned aerial vehicle conducts tests over Naval Air Station Patuxent River, Maryland, USA 25 June 2010](https://ichef.bbci.co.uk/news/976/cpsprodpb/15E89/production/_107473798_75525269-9331-47b3-bfdb-bb8673acada8.jpg)image copyrightEPA

image captionThe US military identified the drone as a US Navy RQ-4A Global Hawk (file photo)

**A US military surveillance drone has been shot down by Iranian forces while flying over the Strait of Hormuz.**

Iran's Islamic Revolution Guards Corps (IRGC) said the aircraft had violated Iranian airspace, and that the incident sent a "clear message to America".

But the US military insisted the drone had been over international waters at the time, and condemned what it called an "unprovoked attack" by the IRGC.

President Donald Trump tweeted: "Iran made a very big mistake!"

The incident comes at a time of escalating tension between the two countries.

On Monday, the US defence department said it was deploying 1,000 extra troops to the region in response to "hostile behaviour" by Iranian forces. It has already sent an aircraft carrier strike group and B-52 bombers.

The US has also accused Iran of attacking two oil tankers with mines last Thursday just outside the Strait of Hormuz, in the Gulf of Oman. Iran rejects the allegation.

media captionThe BBC's Mark Lowen reports: "It has sparked huge international tension"

It was the second time in a month tankers had been attacked close in the region, through which a fifth of the world's oil passes each day.

Tensions were further fuelled on Monday when Iran announced its stockpile of low-enriched uranium would next week exceed limits it agreed with world powers under a landmark nuclear deal in 2015.

Iran stepped up its production in response to tightening economic sanctions from the US, which unilaterally withdrew from the deal last year.

What happened on Thursday?
--------------------------

[The IRGC said its air force had shot down a US "spy" drone in the early hours](https://en.irna.ir/news/83362061/Iran-shoots-down-US-spy-drone) after the unmanned aircraft violated Iranian airspace near Kuhmobarak in the southern province of Hormozgan.

In a speech carried live on Iranian state television, IRGC commander-in-chief Maj-Gen Hossein Salami warned the US to respect Iran's territorial integrity.

![Map of Iran and Strait of Hormuz showing Kuhmobarak](https://ichef.bbci.co.uk/news/640/cpsprodpb/16E6F/production/_107470839_strait_of_hormuz_640-nc.png)

![Presentational white space](https://ichef.bbci.co.uk/news/624/cpsprodpb/17B75/production/_105914179_blank_white_space-nc.png)

"Those who defend the borders of the Islamic nation of Iran will react in a total and decisive way to any intrusions by foreign elements on our land. Our borders are our red line."

He added: "Iran is not seeking war with any country, but we are fully prepared to defend Iran."

The US military's Central Command confirmed a US Navy Broad Area Maritime Surveillance (BAMS-D) aircraft was shot down by an Iranian surface-to-air missile system while operating in what it said was international airspace over the Strait of Hormuz at 23:35 GMT on Wednesday (04:05 Iran time on Thursday).

![US Air Force Staff Sgt Seth Thurber checks panels of a RQ-4 Global Hawk unmanned surveillance drone during a pre-flight inspection on 5 February 2019, at Beale Air Force Base, California (5 February 2019)](https://ichef.bbci.co.uk/news/976/cpsprodpb/15A5B/production/_107476688_f091206f-ec77-411a-9902-012cd29c10b3.jpg)image copyrightAFP

image captionIran said it targeted a US "spy" drone after the unmanned aircraft violated Iranian airspace

"Iranian reports that the aircraft was over Iran are false," spokesman Navy Capt Bill Urban said. "This was an unprovoked attack on a US surveillance asset in international airspace."

Reuters news agency later cited a US source as saying US naval assets had been dispatched to the drone debris field in international waters.

The BAMS-D is a RQ-4A Global Hawk High-Altitude, Long, Endurance (HALE) drone that can carry out surveillance and reconnaissance missions over vast ocean and coastal regions, according to the US military.

![Presentational grey line](https://ichef.bbci.co.uk/news/464/cpsprodpb/10301/production/_98950366_presentational_grey_line464-nc.jpg)

First direct incident of crisis
-------------------------------

![Analysis box by Jonathan Marcus, defence correspondent](https://ichef.bbci.co.uk/news/1536/cpsprodpb/147AA/production/_106028838_jonathanmarcus-nc.png)

This is the first direct incident of the current crisis involving the US and Iranian militaries and is a powerful reminder of the dangers of escalation in the Gulf.

As far as the Iranians are concerned, the downing of the drone was intended to send a clear and explicit message to the Americans - "our borders are our red line" - a point underscored by the IRGC's commander-in-chief.

So there is no doubting who shot down the US drone, an MQ-4C Triton. It is a massive aircraft with a wing-span equivalent to a small airliner. But the two sides differ as to where it happened. The Iranians say it was in their airspace; the Americans say that it was not.

According to some reports, US President Donald Trump himself is eager to dial down the tension, fearing a spillover into outright conflict. But this is just the kind of incident that could provoke just such a cycle of action and response.

![Presentational grey line](https://ichef.bbci.co.uk/news/464/cpsprodpb/10301/production/_98950366_presentational_grey_line464-nc.jpg)

Is this the first time Iran has targeted a US drone?
----------------------------------------------------

[Last week, the US military accused Iran of attempting to shoot down a US MQ-9 Reaper armed drone](https://www.centcom.mil/MEDIA/STATEMENTS/Statements-View/Article/1877252/statement-from-us-central-command-on-attacks-against-us-observation-aircraft/) with a surface-to-air missile in an attempt to disrupt surveillance of one of the tankers that was attacked, the Kokuka Courageous.

The drone had earlier observed a fire on board the other tanker, the Front Altair.

media captionWhy does the Strait of Hormuz matter?

The previous week, another US MQ-9 Reaper was shot down over Yemen by a surface-to-air missile fired by the Iran-backed rebel Houthi movement.

The US military said the altitude of the engagement "indicated an improvement over previous Houthi capability, which we assess was enabled by Iranian assistance". Iran denies providing weapons to the Houthis.

In 2011, Iran said it had captured a US RQ-170 Sentinel reconnaissance drone that had been reported lost by US forces in neighbouring Afghanistan. It developed its own version of the drone, one of which was shot down by Israel last year.

![Presentational grey line](https://ichef.bbci.co.uk/news/464/cpsprodpb/10301/production/_98950366_presentational_grey_line464-nc.jpg)

US-Iran tension: Recent events
------------------------------

**May 2018:** US President Donald Trump withdraws unilaterally from the 2015 nuclear deal between Iran and six world powers, and begins reinstating sanctions to force Iran to renegotiate the accord. Iran's economy slumps as they take effect.

**2 May 2019:** Mr Trump steps up pressure on Tehran by ending exemptions from secondary sanctions for countries still buying Iranian oil.

**5 May:** The US sends an aircraft carrier strike group and B-52 bombers to the Gulf because of "troubling and escalatory indications" related to Iran.

**8 May:** Iranian President Hassan Rouhani says Iran will scale back its commitments under the nuclear deal in retaliation for the sanctions, including by allowing its stockpile of low-enriched uranium to increase. Enriched uranium is used to make reactor fuel and potentially nuclear weapons.

**12 May:** Four oil tankers are damaged by explosions off the UAE coast in the Gulf of Oman. The UAE says the blasts were caused by limpet mines planted by a "state actor". The US blames Iran, but it denies the allegation.

**13 June:** Explosions hit two oil tankers in the Gulf of Oman. The US again accuses Iran, releasing footage purportedly showing Iranian forces removing an unexploded limpet mine from a damaged vessel. Iran says the evidence is fabricated.

**17 June:** Iran says it will breach the limit on its stockpile of enriched uranium set under the nuclear deal on 27 June, unless Europe protects Iranian oil sales.

**20 June:** Iranian forces shoot down US military drone over the Strait of Hormuz.


[Source](https://www.bbc.com/news/world-middle-east-48700965)