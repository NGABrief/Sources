# Advancing the Maximum Pressure Campaign by Restricting Iran's Nuclear Activities - United States Department of State

> Maximum Pressure Campaign The Administration has imposed the toughest sanctions ever on the Iranian regime. We will continue to apply maximum pressure until Iran’s leaders change their destructive behavior, respect the rights of their people, and return to the negotiating table. The United States is committed to denying Iran any pathway to nuclear weapons. Today, […]

Fact Sheet

Washington, DC

May 3, 2019

**Maximum Pressure Campaign**

*   The Administration has imposed the toughest sanctions ever on the Iranian regime. We will continue to apply maximum pressure until Iran’s leaders change their destructive behavior, respect the rights of their people, and return to the negotiating table.
*   The United States is committed to denying Iran any pathway to nuclear weapons. Today, Secretary Pompeo further increased U.S. pressure on Iran’s nuclear program, following earlier steps taken in November 2018 and March 2019.
*   In November 2018, the United States re-imposed sanctions on nuclear cooperation with Iran, including by re-designating 23 Atomic Energy Organization of Iran entities and individuals, and by placing new limits on foreign assistance that could expand Iran’s nuclear program beyond current restrictions.
*   In March 2019, the United States designated an additional 31 Iranian individuals and entities linked to Iran’s WMD proliferation-sensitive activities. These included scientists who had worked on Iran’s former nuclear weapons program and who remain employed by Iran on potentially sensitive dual-use technologies under the leadership of the former head of that nuclear weapons program.

**Increasing Nuclear Pressure**

*   Secretary Pompeo continues to believe that Iran must declare to the IAEA a full account of the prior military dimensions of its nuclear program, and verifiably abandon such work in perpetuity. Additionally, he reiterates his call that Iran must stop enrichment and never pursue plutonium reprocessing.
*   Today’s action by Secretary Pompeo applies additional pressure on Iran’s nuclear program. Starting May 4, assistance to expand Iran’s Bushehr Nuclear Power Plant beyond the existing reactor unit will be exposed to sanctions.
*   Until Iran ends its destabilizing behavior and returns to the negotiating table in order to reach the comprehensive and enduring deal outlined by Secretary Pompeo in May 2018, there cannot be business as usual with Iran, in particular with its nuclear program, and we will not countenance any expansion of Iran’s involvement with nuclear materials or technology.
*   In addition, any involvement in transferring enriched uranium out of Iran in exchange for natural uranium will now be exposed to sanctions. The United States has been clear that Iran must stop all proliferation-sensitive activities, including uranium enrichment, and we will not accept actions that support the continuation of such enrichment.
*   We will also no longer permit the storage for Iran of heavy water it has produced in excess of current limits; any such heavy water must not be made available to Iran in any fashion.

**Tightening Restrictions on Iran’s Nuclear Activities**

*   Today, Secretary Pompeo also tightened restrictions that impede Iran’s ability to reconstitute its past nuclear weapons program and help prevent Iran from shortening the time it would take to produce fissile material for a nuclear weapon. We are permitting the temporary continuation of certain ongoing nonproliferation projects that constrain Iran’s nuclear activities and that help maintain the nuclear _status quo_ in Iran until we reach a comprehensive deal that resolves Iran’s proliferation threats.
*   Specifically, we are permitting the following nonproliferation activities to continue, for a renewable duration of 90 days:
    *   the redesign of the Arak reactor to prevent it from becoming a factory for weapons-grade plutonium;
    *   modification of infrastructure at the Fordow facility to help ensure that the facility is no longer used for uranium enrichment work;
    *   work at the existing unit at the Bushehr Nuclear Power Plant to ensure safe and transparent operations, as well as to facilitate foreign fuel supply and take-back that precludes any legitimate need for Iran to enrich uranium and denies it access to spent fuel from which plutonium might be separated;
    *   provision of enriched uranium on an as-needed basis for the Tehran Research Reactor (TRR) under international verification so as to preclude any need for indigenous TRR fuel production; and
    *   the transfer out of Iran of scrap and spent nuclear reactor fuel, to ensure that such sensitive material cannot be reprocessed or further enriched in Iran.
*   We reserve the right to modify or revoke our policy covering these non-proliferation activities at any time.
*   In combination with our sanctions, these nonproliferation activities enhance our ability to constrain Iran’s program and keep pressure on the regime while we pursue a new, stronger deal.
*   Iran must be strictly held to current nuclear limits until the global pressure campaign has brought it to the table to conclude a better and more comprehensive deal. We join partners and allies around the world in making clear that Iran must continue to allow full, timely, and unimpeded access to International Atomic Energy Agency inspectors.


[Source](https://2017-2021.state.gov/advancing-the-maximum-pressure-campaign-by-restricting-irans-nuclear-activities/index.html)