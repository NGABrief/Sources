# The Killing of Gen. Qassim Suleimani: What We Know Since the U.S. Airstrike (Published 2020)

> Iran’s supreme leader, Ayatollah Ali Khamenei, promised retaliation. The U.S. moved to send more troops to the Middle East. And a deluge of threats on social media.

Iran’s supreme leader, Ayatollah Ali Khamenei, promised retaliation. The U.S. moved to send more troops to the Middle East. And a deluge of threats on social media.

Published Jan. 3, 2020Updated Jan. 4, 2020

Video

transcript

transcript

Video Shows Aftermath of U.S. Strike That Killed Top Iran Commander
-------------------------------------------------------------------

#### President Trump authorized the attack early Friday at Baghdad International Airport that killed Iran’s top security and intelligence commander, Maj. Gen. Qassim Suleimani.

Suleimani was plotting imminent and sinister attacks on American diplomats and military personnel. But we caught him in the act. We took action last night to stop a war. We did not take action to start a war.

![Video player loading](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing-span/merlin_166605342_bb1d07c1-25be-4a96-8815-857e98b24a47-videoSixteenByNine3000.jpg)

President Trump authorized the attack early Friday at Baghdad International Airport that killed Iran’s top security and intelligence commander, Maj. Gen. Qassim Suleimani.CreditCredit...Ali Mohammadi/Bloomberg News

Trump says airstrike was ordered ‘to stop a war.’
-------------------------------------------------

President Trump said Friday afternoon that the airstrike that killed Maj. Gen. Qassim Suleimani, the powerful Iranian commander, was ordered “to stop a war” and prevented attacks on Americans.

“Suleimani was plotting imminent and sinister attacks on American diplomats and military personnel, but we caught him in the act and terminated him,” he said, speaking to reporters from his resort in West Palm Beach, Fla. “We took action last night to stop a war, we did not take action to start a war.”

Mr. Trump said the United States is not seeking regime change in Iran, but called for Tehran’s “aggression in the region” to immediately end. He also warned Iran against retaliating, saying, “If Americans anywhere are threatened, we have all of those targets already fully identified, and I am ready and prepared to take whatever action is necessary.”

He added, “that in particular refers to Iran.”

The airstrike directed by Mr. Trump dramatically ratcheted up tensions between Washington and Tehran, and Iran’s leaders quickly promised retaliation for the general’s killing.

Around the time of the overnight strike, a Special Operations unit based in the United States boarded transport aircraft bound for the Middle East, one Defense Department official said.

The deployment of the elite Army Rangers was the latest to the region. This week, the Pentagon readied 4,000 troops based at Fort Bragg, N.C., for a similar security mission to Kuwait. They are to depart in the coming days, joining 750 troops already deployed, officials said.

“The brigade will deploy to Kuwait as an appropriate and precautionary action in response to increased threat levels against U.S. personnel and facilities,” a Department of Defense spokesperson said.

General Suleimani, a powerful strategist who represented Iran’s influence across the region, [was killed by an American drone](https://www.nytimes.com/2020/01/02/world/middleeast/qassem-soleimani-iraq-iran-attack.html) at Baghdad’s airport, in an attack that had been authorized by President Trump.

Iraq’s Parliament planned to hold an emergency session over the weekend to address the airstrike, which Prime Minister Adel Abdul Mahdi called “a brazen violation of Iraq’s sovereignty and a blatant attack on the nation’s dignity.” A [powerful Iraqi militia leader was also killed](https://www.nytimes.com/2020/01/03/world/middleeast/Iraq-Iran-Mohandis-airstrike.html).

The strike, regarded by analysts as [perhaps the riskiest American move](https://www.nytimes.com/2020/01/03/world/middleeast/trump-iran-suleimani.html) in the Middle East since the invasion of Iraq in 2003, threatened to inflame hostilities across the region.

Iran’s U.N. ambassador calls Suleimani’s killing ‘an act of war.’
-----------------------------------------------------------------

Iran’s United Nations ambassador, Majid Takht Ravanchi, called the killing of Maj. Gen. Qassim Suleimani “an act of war,” and vowed that it would be met with “revenge, a harsh revenge.”

“Last night, they started a military war by assassinating, by an act of terror, one of our top generals,” Mr. Takht Ravanchi said during an appearance Friday on CNN. “We cannot just remain silent. We have to act and we will act.”

Asked if Iran would act militarily, Mr. Takht Ravanchi said: “That’s for the future to witness.”

Pro-Iranian social media accounts unleash a deluge of threats
-------------------------------------------------------------

In the hours after the American strike, thousands of pro-Iranian social media accounts went to work.

Accounts on Twitter and Instagram tagged the White House with death threats and posted images of President Trump with a severed head and coffins covered in the American flag, alongside the hashtag Operation Hard Revenge.

It was not clear whether the activity was the work of actual accounts or state-backed bots, according to the Atlantic Council’s Digital Forensic Research Lab. But they tweeted pro-Iranian, anti-American content at a rate of 3,000 tweets every 45 minutes, according to New York Times data.

The social media activity may just be an opening salvo, experts said.

Iran may begin a digital campaign of cyberattacks and disinformation in retaliation for General Suleimani’s death, they said. Tehran’s most likely target, the experts added, would be the American private sector.

Over the past year, Iranian hackers have taken aim at Mr. Trump’s presidential campaign. They have also targeted telecom companies, infrastructure systems and more than 200 oil, gas and heavy machinery companies around the world.

The hackers have “developed the ability to disrupt critical infrastructure and they already have the ability to wipe data,” said James A. Lewis, a cybersecurity expert at the Center for Strategic Studies in Washington. “But they’ve gone well beyond that now. The question is what services — pipelines? dams? — will they target now.”

Iran is still not “at the top of the league” of countries with the ability to cause widespread destruction via cyberattacks, Mr. Lewis and other experts said. But Tehran is much further along than American officials gave it credit for in 2009, when a classified intelligence assessment concluded that it had the motivation to inflict harm, but lacked the skills and resources to do so.

Since 2010 — when an Iranian nuclear facility was the target of a joint American-Israeli cyberattack — Tehran has embraced such attacks as part its strategy of “asymmetrical warfare.” While Iran’s Islamic Revolutionary Guards Corps may never match the West in conventional warfare, its specialized teams have learned how much destruction they can cause to vulnerable systems, according to American intelligence assessments and private security researchers.

Over the past five years, American officials and cybersecurity experts have tracked Iranian hackers as they have significantly advanced their capabilities beyond wiping data to sophisticated attacks on financial networks, internet infrastructure, energy companies — and, even more disconcerting, sites like the Bowman Dam in Westchester County and the Energy Department’s Idaho National Engineering Laboratory near Idaho Falls.

“They now have the ability to do serious harm,” Mr. Lewis said. “As the conflict with the U.S. continues, they’re going to be tempted. Expect to see a lot more testing of how far they can get into company networks, universities, federal networks and smaller government networks in towns and cities.”

Iran promises ‘forceful revenge’ for general’s killing.
-------------------------------------------------------

Iranian leaders issued strident calls on Friday for revenge against the United States after the killing of Maj. Gen. Qassim Suleimani [in an overnight airstrike at the Baghdad airport](https://www.nytimes.com/2020/01/02/world/middleeast/qassem-soleimani-iraq-iran-attack.html).

His death is a considerable blow to Tehran, and Iran’s supreme leader, Ayatollah Ali Khamenei, called for retaliation and for three days of national mourning.

“His departure to God does not end his path or his mission, but a forceful revenge awaits the criminals who have his blood and the blood of the other martyrs last night on their hands,” the supreme leader said in a statement.

Iran’s security body also pledged to avenge General Suleimani’s killing in the “right place and time,” saying it had reached a decision on how to do so.

The American strike spurred [mass displays of public mourning](https://twitter.com/Seamus_Malek/status/1213039666519166976) by Iran and its network of allies across the Middle East. Iranian officials said the general’s body would be taken on a funeral procession around Baghdad, and that a funeral would be held for him in Tehran on Sunday.

On Friday, Mr. Trump posted on Twitter about the strike, saying that General Suleimani “killed or badly wounded thousands of Americans over an extended period of time, and was plotting to kill many more … but got caught!”

General Suleimani was the head of the powerful Quds Force of the Islamic Revolutionary Guards Corps and the architect of nearly every significant operation by Iranian intelligence and military forces over the past two decades.

The general’s prominent role meant that his death could have a ripple effect in any number of countries across the Middle East where Iran and the United States compete for influence.

The New York Times; satellite image by Maxar via Bing.

The strike was carried out by an MQ-9 Reaper drone that fired missiles on a convoy of vehicles leaving the airport. Several other officials from Iraqi militias backed by Tehran were also killed.

“This strike was aimed at deterring future Iranian attack plans,” the Pentagon said in a statement. The United States has long been at odds with Iran over its nuclear program and influence in Iraq and other countries in the region. Those tensions have surged under the Trump administration.

The strike on Friday was the latest escalation between the two nations after a rocket attack on an Iraqi military base, believed to have been carried out by an Iran-backed militia, killed [an American contractor](https://www.nytimes.com/2019/12/27/us/politics/american-rocket-attack-iraq.html) in December.

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing-oil/merlin_128266949_6734f689-770c-40a7-8640-0a5d3fdfe31a-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Gas flares at an oil field in Kirkuk. Oil prices jumped on Friday after the news of the general’s killing.](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing-oil/merlin_128266949_6734f689-770c-40a7-8640-0a5d3fdfe31a-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Ivor Prickett for The New York Times

Americans were ordered to evacuate from Iraq, and oil prices rose.
------------------------------------------------------------------

The State Department [urged American citizens to leave Iraq immediately](https://twitter.com/TravelGov/status/1213011491777060864?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed&ref_url=https%3A%2F%2Fapp.dataminr.com%2Fapp%2Fdashboard.html) following the strike that killed General Suleimani in Baghdad, citing “heightened tensions.”

[Oil prices jumped on Friday](https://www.nytimes.com/2020/01/03/business/iran-oil.html) after the news of the general’s death: The price of Brent oil, the international benchmark, surged in the early hours of Hong Kong trading to nearly $70 a barrel — an increase of $3.

The Morning: Make sense of the day’s news and ideas. David Leonhardt and Times journalists guide you through what’s happening — and why it matters.

The immediate increase in the price of oil was among the largest since an [attack on a critical Saudi oil installation](https://www.nytimes.com/2019/09/19/world/middleeast/saudi-iran-attack-oil.html) in September that temporarily knocked out 5 percent of the world’s oil supply.

By 11 a.m. in London, the price of Brent crude oil was at a three-month high of $69.20 a barrel. International oil companies based in the southeastern Iraqi city of Basra have begun evacuating American employees, according to Al Arabiya news outlet.

The Dow Jones industrial average and the S&P 500 each opened about 1 percent lower on Friday, while oil company shares rose, with Exxon Mobil up 1.3 percent and Chevron up 1.2 percent in premarket trading.

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing6/merlin_166600056_5f356ac7-8282-4e6e-80c5-e4a459b03946-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Walking on representations of the United States and Israeli flags on Friday in Baghdad.](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing6/merlin_166600056_5f356ac7-8282-4e6e-80c5-e4a459b03946-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Khalid Mohammed/Associated Press

Pompeo says the U.S. is committed to de-escalation.
---------------------------------------------------

Secretary of State Mike Pompeo said he had spoken to top diplomats in Britain, China and Germany on Friday about what the State Department described as President Trump’s recent decision to carry out the strike “in response to imminent threats to American lives.”

Mr. Pompeo also told his foreign counterparts that the United States was committed to de-escalation, according to the State Department. Mr. Pompeo posted several statements and a video on Twitter that he said showed Iraqis “dancing in the street.” ([Witnesses said](https://www.nytimes.com/2020/01/04/world/pompeo-tweet-Iraq-video.html) that brief demonstration had involved only a small group of men, and that no one else had joined in.)

“This was a man who has put American lives at risk for an awfully long time,” Mr. Pompeo said on Friday on CNN. “Last night was the time that we needed to strike to make sure that this imminent attack that he was working actively was disrupted.”

He declined to provide more details about the looming attack.

One American official familiar with the internal discussions about the drone strike said the administration was still trying to figure out what would come next.

The official, who spoke on the condition of anonymity, said the backlash over General Suleimani’s death could be even more fraught than the tensions after an American raid in 2011 that killed Osama bin Laden, the leader of Al Qaeda, who was part of a stateless group and had no international support.

The Swiss Foreign Ministry said in a statement that a diplomat from Switzerland, which represents American interests in Iran to maintain communication, had delivered a message from the United States to the Iranian Foreign Ministry in Tehran on Friday concerning the death of General Suleimani. It did not elaborate.

“Given the latest events in the region, Switzerland invites both parties to avoid any escalation,” the ministry said.

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing1sub/merlin_162038955_a6cc9383-40a5-4557-b3d9-1facb3f2b6b7-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Maj. Gen. Qassim Suleimani in October. He was behind nearly all military and intelligence operations orchestrated by Iran in the past two decades.](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing1sub/merlin_162038955_a6cc9383-40a5-4557-b3d9-1facb3f2b6b7-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Office of the Iranian Supreme Leader, via Associated Press

Suleimani led 20 years of spying and proxy warfare.
---------------------------------------------------

As the leader of the Quds Force of the Islamic Revolutionary Guards Corps, which leads Iran’s operations abroad, General Suleimani, who was 62, was the country’s [top security and intelligence commander](https://www.nytimes.com/2020/01/02/world/middleeast/general-soleimani-iran-dead.html). He was behind nearly all military and intelligence operations orchestrated by Iran in the past two decades and directed Iran-backed militias in the fight against the Islamic State.

American officials have also accused him of causing the deaths of hundreds of soldiers during the Iraq war and he was believed to have played a central role in orchestrating Iran’s support for the government of President Bashar al-Assad in Syria.

In Iran, General Suleimani was a respected political figure among hard-liners and was close to the supreme leader, Ayatollah Ali Khamenei. To many Iranians, he was also a war hero, after becoming a commander while he was only in his 20s during the Iran-Iraq war in the 1980s.

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing5/merlin_166601742_5689986e-635e-4c1a-a444-e6f155d2f9f0-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![The Treasury Department put Brig. Gen. Ismail Qaani on a blacklist in 2012 for what it called “financial disbursements” to various terrorist groups, including Hezbollah.](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing5/merlin_166601742_5689986e-635e-4c1a-a444-e6f155d2f9f0-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Iranian Supreme Leader Office, via EPA

The general’s deputy succeeded him within hours, according to Iranian news agencies, with Iran’s supreme leader, Ayatollah Ali Khamenei, appointing Brig. Gen. Ismail Qaani as leader of the Quds Force on Friday.

General Qaani, 62, had been the force’s deputy commander since 1997, according to Reuters.

The United States Treasury Department put General Qaani on a blacklist in 2012 for what it called “financial disbursements” to various terrorist groups, including Hezbollah.

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing9/merlin_166605177_903a9877-1261-4a6c-84b4-ee2c71577e8e-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Protesters burning an American flag during a demonstration after Friday Prayer in Tehran following the killing of Maj. Gen. Qassim Suleimani.](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing9/merlin_166605177_903a9877-1261-4a6c-84b4-ee2c71577e8e-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Abedin Taherkenareh/EPA, via Shutterstock

The killing prompted protests in Iran and anger in Iraq.
--------------------------------------------------------

Large crowds gathered for Friday Prayer in Iran and filled public squares with mass protests, while officials met privately to plot strategy and leaders vowed to avenge General Suleimani’s death.

Images broadcast on Iranian state television showed thousands of supporters of General Suleimani gathered in mourning outside his house in the southeastern town of Kerman, and in other cities.

“The great nation of Iran will take revenge for this heinous crime,” President Hassan Rouhani wrote [on Twitter](https://twitter.com/HassanRouhani/status/1213009152093696005).

Iran’s foreign minister, Mohammad Javad Zarif, called the strike an “act of international terrorism.”

Iran was working with Iraqi officials to repatriate the general’s body for a funeral service, perhaps as soon as Saturday, a number of Iranian journalists reported.

Iran’s Supreme National Security Council also held an emergency meeting on Friday, which the supreme leader, Ayatollah Ali Khamenei, attended. The council issued a statement after the meeting saying it had reached a decision on how to respond to the killing, but did not say what that decision was.

“America must know the criminal attack on General Suleimani was its worst strategic mistake in the Middle East and that America will not escape the consequences easily,” the statement read. “As our supreme leader said in his message, a harsh revenge awaits the criminals who have the general’s blood on their hands. These criminals will face revenge at the right time and place.”

In Iraq, the strike appeared likely to accelerate calls for the departure of American troops. Along with General Suleimani, it killed Abu Mahdi al-Muhandis, the leader of a powerful militia that is backed by Iran but under the umbrella of the Iraqi military.

Prime Minister Adel Abdul Mahdi of Iraq praised Mr. al-Muhandis and General Suleimani as heroes in the fight against the Islamic State and condemned their killing as a violation of sovereignty.

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing11/merlin_166514640_a6b2103f-ed51-4739-81f0-0f7fcafc25f5-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Abu Mahdi al-Muhandis, center, a deputy commander of the Iraqi Popular Mobilization Forces, was also killed in the drone strike.](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing11/merlin_166514640_a6b2103f-ed51-4739-81f0-0f7fcafc25f5-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Thaier Al-Sudani/Reuters

The strike also killed a prominent Iraqi commander.
---------------------------------------------------

Friday’s strike in Baghdad also killed Abu Mahdi al-Muhandis, an Iraqi militia leader who was [one of Iran’s top lieutenants in Iraq and a veteran of battles](https://www.nytimes.com/2020/01/03/world/middleeast/iraq-iran-airstrike-al-muhandis.html) against the United States and the Islamic State.

Born Jamal Jaafar Ibrahimi, he was better known by his nom de guerre and gained prominence as mostly Shiite militias formed to fight the Islamic State in 2014. But he was a powerful force in Iraq for years, and his death alone would have sent shock waves through the country.

In 2009, the United States Treasury Department designated Mr. al-Muhandis a “threat to stability in Iraq” and [accused him of helping smuggle rockets, sniper rifles and other weapons](https://www.treasury.gov/press-center/press-releases/Pages/tg195.aspx) into the country from Iran.

Long before the Iraq war, he was accused of playing a role in the bombings of French and American Embassies in Kuwait in 1983, and the later attempt to assassinate Kuwait’s emir.

Much of Mr. al-Muhandis’s history remains murky, including his exact age: He would have been about 66 or 67 at the time of his death, according to the United States government, which has said he was born in 1953 in Basra, Iraq.

Mr. al-Muhandis fled Iraq with the rise of Saddam Hussein and spent years in exile in Iran, cultivating close ties with Iranian officials, becoming fluent in Persian and keeping a home in Tehran. He returned to Iraq in the aftermath of the American invasion in 2003 and briefly served in Iraq’s Parliament before dropping out of public view.

He helped found a militia that fought against the United States, and was accused of training and equipping a network of anti-American groups. The militia has continued to oppose the United States, and American officials blamed it for the rocket attack that killed an American contractor last week.

In a reflection of the chaos that has engulfed Iraq and the region, it was only five years after the Treasury Department put sanctions on Mr. al-Muhandis that he found himself effectively on the same side as the United States. The invasion of Iraq by the Islamic State from Syria gave his militia, Iran and the United States a common enemy.

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing12/merlin_161138055_8e7adc80-2831-4544-bd0e-c000c38a0765-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![The leader of Hezbollah, Hassan Nasrallah, said it was the responsibility of all resistance fighters to seek “just retribution” against “the most evil criminals in the world,” meaning the United States.](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing12/merlin_161138055_8e7adc80-2831-4544-bd0e-c000c38a0765-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Bilal Hussein/Associated Press

Iran’s regional allies joined in the outrage.
---------------------------------------------

Iranian allies across the Arab world condemned the United States, reflecting the strength of the regional network General Suleimani spent much of his life building, including links to the government of Syria and militant groups in Lebanon, Gaza, Yemen and elsewhere.

The leader of Hezbollah, the Lebanese militant group and political party that General Suleimani helped build, vowed in a statement that his group would continue on the path the general set and “work night and day to achieve his goals.”

It was the responsibility of all resistance fighters to seek “just retribution” against “the most evil criminals in the world,” the leader, Hassan Nasrallah, said, meaning the United States.

In Yemen, the administration run by the Houthi rebels, who have received support from Iran in their war against Saudi Arabia, condemned the United States strike as a “cowardly attack” that “makes clear the increasing American spite against all who are in favor of justice for the Islamic world.”

In Syria, where General Suleimani oversaw a huge effort to shore up the government of President Bashar al-Assad, a foreign ministry official condemned the “treacherous, criminal American aggression” that led to his killing, the state news agency SANA reported on Friday.

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing8/merlin_166489797_81e4fbd2-9ad1-4fa2-977a-50b333436a38-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Foreign Minister Mohammad Javad Zarif of Iran, left, with his Russian counterpart, Sergei Lavrov, in Moscow on Monday.](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing8/merlin_166489797_81e4fbd2-9ad1-4fa2-977a-50b333436a38-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Evgenia Novozhenina/Reuters

International leaders urged ‘maximum restraint.’
------------------------------------------------

António Guterres, the United Nations’ secretary general, voiced his deep concern over the recent rise in tensions in the Middle East, his spokesman, Farhan Haq, said in a statement.

“The world cannot afford another war in the Gulf,” the statement read. “This is a moment in which leaders must exercise maximum restraint.”

The killing of General Suleimani “most likely” violated international law, Agnes Callamard, the United Nations expert on extrajudicial executions, said in a post on Twitter.

“Use of lethal force is only justified to protect against an imminent threat to life,” Ms. Callamard wrote. Use of drones for targeted killings outside active hostilities was “almost never likely to be legal,” she added.

Many experts also said on Friday that the strike probably [ended any prospect of negotiations to save the Joint Comprehensive Plan of Action](https://www.nytimes.com/2020/01/03/world/europe/soleimani-iran-nuclear.html), the landmark nuclear agreement Iran signed in 2015 with the United States, China, Russia, Britain, France and Germany. The recent escalation in tensions between the United States and Iran began with the 2018 decision by President Trump to withdraw from the deal.

The Russian Foreign Ministry called the killing of General Suleimani “an adventurist step that will increase tensions throughout the region,” according to local news agencies.

A spokesman for the Chinese Foreign Ministry called for restraint on all sides, “especially the United States.”

“China has always opposed the use of force in international relations,” the spokesman, Geng Shuang, said at a daily news briefing, according to news agencies.

Britain’s foreign secretary, Dominic Raab, called on Friday for a de-escalation in tensions and said that further conflict in the region was not in his country’s interest.

“We have always recognized the aggressive threat posed by the Iranian Quds force led by Qassim Suleimani,” Mr. Raab said in a statement. “Following his death, we urge all parties to de-escalate.”

Federica Mogherini, the former European high representative for foreign and security policy, said on Twitter that the general’s killing was “an extremely dangerous escalation.”

In France, the country’s junior minister for European affairs, Amélie de Montchalin, said that she would soon consult with countries in the region.

“We have woken up to a more dangerous world,” Ms. de Montchalin told French radio, calling for “stability and de-escalation.”

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing7/merlin_166577184_cb8bf8f2-067e-4c8f-a122-c39002177053-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![“Israel stands with the United States in its just struggle for peace, security and self-defense,” Prime Minister Benjamin Netanyahu said.](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing7/merlin_166577184_cb8bf8f2-067e-4c8f-a122-c39002177053-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Alkis Konstantinidis/Reuters

Netanyahu praised Trump for the strikes.
----------------------------------------

Prime Minister Benjamin Netanyahu of Israel cut short an official visit to Greece to return to Israel on Friday after the killing of Maj. Gen. Qassim Suleimani.

Before boarding the plane, Mr. Netanyahu praised President Trump for “acting swiftly, forcefully and decisively.”

General Suleimani, a longtime adversary of Israel, was credited with overseeing many attacks against Israeli and Jewish targets and he was linked with an attack on the Israeli Embassy in Argentina in the 1990s. More recently, he was behind military actions from Syria, across Israel’s northern frontier.

Hamas, the Islamic militant group that controls the Palestinian coastal territory of Gaza, condemned what it called “U.S. bullying” that it said served the interests of Israel.

It offered condolences to Iran on the death of General Suleimani, saying in a statement that he had “played a major and critical role in supporting Palestinian resistance at all levels.”

Bassem Naim, a spokesman for the group, said on Twitter that the assassination “opens the doors of the region to all possibilities, except calm & stability.”

![](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing4/merlin_166187784_aa1752f9-6823-4acb-9a77-01850ecc0aa2-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Speaker Nancy Pelosi, in a statement, warned that the attack “risks provoking further dangerous escalation of violence.”](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing4/merlin_166187784_aa1752f9-6823-4acb-9a77-01850ecc0aa2-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Erin Schaff/The New York Times

Congress is divided over the killing.
-------------------------------------

Speaker Nancy Pelosi demanded that the administration brief the full Congress on the strike and the next steps under consideration, noting that the move was made without lawmakers’ consultation or an authorization of military force.

Ms. Pelosi spoke with Mark T. Esper, the defense secretary, Thursday night after the attack, an aide said, but was not given advance notice.

The strike, Ms. Pelosi [said in a statement](https://www.speaker.gov/newsroom/1220) late Thursday evening, “risks provoking further dangerous escalation of violence. America — and the world — cannot afford to have tensions escalate to the point of no return.”

In stark contrast, Republican lawmakers — including both Iran hawks and those who have frequently clashed with Mr. Trump over his foreign policy — have almost uniformly praised the move.

“Will there be escalation? Yes. But the escalation is not on our part,” Representative Adam Kinzinger of Illinois, who was stationed twice in Iraq with the Air Force, told CNN. “We’re finally responding to continued provocations by Iran.”

The strike immediately spurred [debate among American lawmakers](https://www.nytimes.com/2020/01/02/world/trump-qassim-suleimani-twitter.html) about President Trump’s war powers and [left congressional leaders sharply divided along party lines](https://www.nytimes.com/2020/01/02/us/politics/us-iran-war.html).

Senator Tom Udall, Democrat of New Mexico, accused Mr. Trump of bringing the nation “to the brink of an illegal war with Iran.”

Senator Marco Rubio, Republican of Florida, [said on Twitter](https://twitter.com/marcorubio/status/1212923281126428676) that Mr. Trump had “exercised admirable restraint” and added that the Quds Force were “entirely to blame.”

Reporting was contributed by Ben Hubbard, Farnaz Fassihi, Megan Specia, Isabel Kershner, Ronen Bergman, Lara Jakes, Eileen Sullivan, Thomas Gibbons-Neff, Elian Peltier, Catie Edmondson, Benjamin Mueller, Alan Yuhas, Nick Cumming-Bruce, Nicole Perlroth, Ben Decker and Joan Nassivera.


[Source](https://www.nytimes.com/2020/01/03/world/middleeast/iranian-general-qassem-soleimani-killed.html?action=click&module=RelatedLinks&pgtype=Article)