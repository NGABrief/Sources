# Iran plane crash: Ukrainian jet was 'unintentionally' shot down

> The country previously denied responsibility for Wednesday's crash, which killed 176 people.

media captionFootage appears to show missile strike on Ukrainian plane in Iran

**Iran has admitted "unintentionally" shooting down a Ukrainian passenger jet, killing all 176 people on board.**

An investigation found that "missiles fired due to human error", President Hassan Rouhani said. He described the crash as an "unforgivable mistake".

The military said the jet turned towards a sensitive site belonging to Iran's Revolutionary Guards and was then mistaken for a cruise missile.

Iran had previously rejected suggestions that it was to blame.

The downing of Ukraine International Airlines flight PS752 on Wednesday came just hours after Iran carried out missile strikes on two airbases housing US forces in Iraq.

The strikes were a response to the killing of senior Iranian commander Qasem Soleimani in a US drone strike in Baghdad on 3 January.

Iran initially denied reports that one of its missiles had brought down the Ukrainian plane near the capital, Tehran. But pressure quickly mounted after Western intelligence officials said evidence pointed to Iranian involvement.

![Search and rescue teams comb the wreckage of a Boeing 737 that crashed near Imam Khomeini Airport](https://ichef.bbci.co.uk/news/976/cpsprodpb/2E83/production/_110470911_059009594-1.jpg)image copyrightEPA

image captionThe plane came down shortly after taking off from Tehran

The Ukrainian flight, which was en route to Kyiv, came down near Imam Khomeini Airport shortly after take-off. Victims included dozens of Iranians and Canadians, as well as nationals from Ukraine, the UK, Afghanistan and Germany.

What explanation did Iran give?
-------------------------------

On Saturday morning, an Iranian military statement read on state TV announced that it had struck flight PS752 with a missile by mistake.

It said the plane had turned towards a "sensitive military centre" of the Revolutionary Guards, a force set up to defend the country's Islamic system. The statement said it had the "flying posture and altitude of an enemy target".

Because of heightened tensions with the US, Iran's military "was at its highest level of readiness", the statement added. "In such a condition, because of human error and in an unintentional way, the flight was hit."

![Search and rescue teams comb the wreckage of a Boeing 737 that crashed near Imam Khomeini Airport in Iran just after takeoff on January 08, 2020](https://ichef.bbci.co.uk/news/976/cpsprodpb/14F92/production/_110460958_gettyimages-1192534506.jpg)image copyrightGetty Images

image captionIran had previously denied it was a missile strike that downed the Ukrainian jet

The military apologised for downing the plane, saying it would upgrade its systems to prevent such "mistakes" in the future. It added that those responsible would be held accountable and prosecuted.

Ukraine International Airlines denies that the plane veered from its expected course before the crash. It says officials should have closed the airport.

Brig-Gen Amir Ali Hajizadeh, the Revolutionary Guards aerospace commander, said the force took "full responsibility" for the crash.

He said a request had been made for a no-fly zone in the area before the incident but - for reasons that are unclear - this was rejected.

Gen Hajizadeh also said the aircraft was shot down by a short-range missile that exploded next to it. He said he informed the authorities about what had happened on Wednesday, days before Iran publicly admitted its involvement.

Iran's Supreme Leader Ali Khamenei ordered the military to investigate "the possible shortcomings or mistakes" that led to the crash.

In a statement, he said there was "proof of human error" and confirmed that he had "requested the relevant authorities to take necessary measures to prevent" it happening again.

Foreign Minister Javad Zarif apologised to the families of the victims but laid part of the blame on the US. "Human error at a time of crisis caused by US adventurism led to \[this\] disaster," he said.

And [Iran's ambassador to the UK, Hamid Baeidinejad, apologised for sharing "wrong findings"](https://twitter.com/baeidinejad/status/1215909313451036673) about the crash. He had said Iran was "confident" that a missile had not been launched.

"I conveyed the official findings... that \[a\] missile could not be fired and hit the Ukrainian plane at that period of time," he said. "I apologise."

![Presentational grey line](https://ichef.bbci.co.uk/news/640/cpsprodpb/1226D/production/_105894347_grey_line-nc.png)

An act of de-escalation
-----------------------

![Analysis box by Lyse Doucet, chief international correspondent](https://ichef.bbci.co.uk/news/1536/cpsprodpb/135BF/production/_104759297_lysedoucet-nc.png)

This is a major admission at a crucial moment for Iran.

Taking responsibility for such a tragic error is highly unusual, but so is the crisis that now confronts the Islamic Republic.

Iran has decided it has to own this disaster to avoid it triggering another war of words with the West or exacerbating further anger and anguish among its own people, who are reeling from one calamity after another.

Make no mistake, this admission was an act of de-escalation.

The repercussions at home may soon be clear. Iran's foreign minister has already sought to shift blame by saying it was "a crisis caused by US adventurism".

But the big question now is: who took the decision to allow a civilian airliner to take off when Iran's airspace was shot through with such tension?

![Presentational grey line](https://ichef.bbci.co.uk/news/640/cpsprodpb/1226D/production/_105894347_grey_line-nc.png)

What has the reaction been?
---------------------------

There were 57 Canadian nationals on board the downed flight and the country's Prime Minister Justin Trudeau described the crash as "a national tragedy".

In a statement, he demanded "transparency and justice for the families and loved ones of the victims".

"We will continue working with our partners around the world to ensure a complete and thorough investigation," he said.

media captionUkraine International Airlines president: ''No more insinuations''

Ukrainian President Volodymyr Zelensky called on Iran to punish those responsible. "We expect Iran... to bring the guilty to the courts," he said.

Elsewhere, the president of Ukraine International Airlines said: "We didn't doubt for a second that our crew and our plane couldn't be the cause for this horrible crash".

"These were our best guys and girls. The best," Yevhenii Dykhne said of the nine crew members who were on board.

Separately, Ukraine's top security official said his country's investigators had gathered conclusive evidence of a missile strike before Iran admitted responsibility on Saturday.

Oleksiy Danilov showed the BBC's Jonah Fisher photographs of the aircraft which he said proved it had been downed by a missile. [The president's office also released images which it said supported this.](https://twitter.com/JonahFisherBBC/status/1215939745664110593)

What happened before Iran's announcement?
-----------------------------------------

The statement marks a stark departure from the denials of recent days. As recently as Friday, Iran was insistent that the plane had not been shot down.

"The thing that is clear to us and that we can say with certainty is that this plane was not hit by a missile," Iran's Civil Aviation Organisation (CAOI) chief Ali Abedzadeh said.

![Map showing Iran plane crash](https://ichef.bbci.co.uk/news/640/cpsprodpb/FAD8/production/_110461246_ukranian_plane_crash_map640_v3-nc.png)

![White space](https://ichef.bbci.co.uk/news/624/cpsprodpb/1460/production/_110461250__109028083_1px_white_line-nc.png)

On Thursday, government spokesman Ali Rabiei accused the US and its allies of "lying and engaging in psychological warfare" by speculating about the cause of the crash.

But as evidence pointing to a missile strike built, calls for a transparent investigation grew louder.

[Video obtained by the New York Times](https://www.nytimes.com/2020/01/09/video/iran-plane-missile.html) appeared to show a missile streaking across the night sky and then exploding on contact with a plane.

media captionMobile phone footage appears to show the plane in the moments before it came down

On Thursday, TV images showed a mechanical digger helping to clear debris from the crash site, raising concerns that important evidence could have been removed.

In response, Iran promised a full investigation, inviting air accident agencies from Ukraine, Canada and the US to take part.

A missile strike on a passenger plane is not unprecedented. In 1988, an Iranian aircraft was shot down in error by a US navy warship and 290 people were killed.

And in 2014, a Russian-made missile hit a Malaysian civilian airliner over Ukraine, killing 298 people.


[Source](https://www.bbc.com/news/world-middle-east-51073621)