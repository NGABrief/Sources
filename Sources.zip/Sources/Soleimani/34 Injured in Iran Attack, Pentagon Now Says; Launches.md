# 34 Injured in Iran Attack, Pentagon Now Says; Launches a Review of Reporting Procedures

> SecDef Mark Esper ordered a review of “processes for tracking and reporting injuries” after criticism in the wake of the Iranian missile attack.

![U.S. soldiers stand at a site of Iranian bombing at Ain al-Asad air base in Anbar, Iraq, Monday, Jan. 13, 2020.](https://cdn.defenseone.com/media/img/upload/2020/01/24/D1-image-to-post_EWmMVtl/860x394.jpg)

U.S. soldiers stand at a site of Iranian bombing at Ain al-Asad air base in Anbar, Iraq, Monday, Jan. 13, 2020. AP / Qassim Abdul-Zahra

Thirty-four U.S. troops have been diagnosed with concussions and other traumatic brain injuries suffered in the [Jan. 8 Iranian missile attack](https://www.defenseone.com/threats/2020/01/iranian-ballistic-missiles-hit-us-base-iraq-pentagon-says/162293/) in Iraq, senior Pentagon spokesman Jonathan Hoffman said Friday. 

Of those, 17 have returned to active duty, Hoffman said. Eight arrived in the United States today for continuing out-patient treatment, and nine remain at the medical facility in Landstuhl, Germany. Sixteen were diagnosed in Iraq, remained there, and have since returned to active duty. 

Hoffman described those figures as a “snapshot in time” and said they could change in coming days. 

Defense Secretary Mark Esper has ordered a review of “processes for tracking and reporting injuries,” Hoffman said. 

The department has come under fierce scrutiny for the lag-time in the reporting of injuries from the missile attack. President Trump after the attack said that no troops had been injured; only after media outlets, including _Defense One,_ began to [report concussions and other TBIs](https://www.defenseone.com/threats/2020/01/eleven-us-troops-were-injured-jan-8-iran-missile-strike/162502/?oref=d1-in-article) did U.S. Central Command issue a statement acknowledging the injuries — eleven service members, originally. 

“A lot of these symptoms are late-developing. They manifest over a period of time,” Hoffman said Friday. “Do we report when someone just shows up with a symptom? Do we wait until we suspect something? Do we wait until they have a full diagnosis? Do we wait until they’re evacuated from the region and are no longer available for duty?”

“That’s the case in what happened in this case. The reporting did not come up until they were actually evacuated from the area and taken to Germany for further treatment, and at that point they were lost to the formation and the secretary was made aware.”

But he acknowledged that there needs to be more “clarity” in how injuries are reported within DOD, and by extension, to the public. 

“The secretary’s direction is focused on the fact if you look at the different types of reporting systems we have, sometimes the administrative reporting of an injury is different than the medical reporting,” he said. “We need to get that clarified.”

On Wednesday, President Donald Trump [downplayed](https://www.defenseone.com/threats/2020/01/toll-mounts-trump-downplays-injuries-suffered-iranian-attack/162586/) the injuries as “headaches.” 

“I heard that they had headaches, and a couple of other things, but I would say, and I can report, it's not very serious,” Trump said in Davos, Switzerland.

The president has previously said that he would be reluctant to allow his young son to play football because of the danger associated with head injuries common in the sport. 

Trump’s remark that he did not consider TBIs to be “very serious” struck some veterans’ advocates as deeply callous — and appeared to contradict the seriousness with which the Defense Department itself handles concussions and other TBIs. The Pentagon and the VA have spent “billions” researching, diagnosing and treating such injuries, [according to](https://twitter.com/Carter_PE/status/1219967477062479872?s=20) Phillip Carter, now a veterans expert with RAND. The Army, which as part of the Defense Department designates March as “TBI Awareness Month,” calls it the “[signature wound](https://www.google.com/search?hl=en&ei=Fq4oXuGyJcqb5gL38a-YAg&q=site%3Aarmy.mil+%22signature+wound%22+Traumatic+Brain+Injury&oq=site%3Aarmy.mil+%22signature+wound%22+Traumatic+Brain+Injury&gs_l=psy-ab.3...3767.4050..4889...0.0..0.67.200.4......0....1j2..gws-wiz.PQ_rrMokNCw&ved=0ahUKEwjhlYLTg5jnAhXKjVkKHff4CyMQ4dUDCAs&uact=5)” of the wars in Iraq and Afghanistan.

Some analysts have speculated that Trump’s comments may have been an effort to deescalate tensions with Iran, given that he has in the past made attacks on U.S. personnel a “red line.”

Former DOD officials say that the more time passes, the less valid that excuse becomes. 

“It's plausible that the day after the attack, both wanting to de-escalate tensions and because the extent of the injuries was likely not yet known, there was reason not to release the injury information,” [tweeted](https://twitter.com/DaveLapanDC/status/1220464755988746243?s=20) former DOD spokesman David Lapan. “However, those reasons diminished in the following days, not 2 weeks later.”

![](https://cdn.defenseone.com/media/img/upload/2020/01/24/DB_lander/860x394.png)

January 24, 2020

*   [The D Brief](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/topic/The-d-brief/?oref=d1-article-topics)

**Tens of thousands of protesters demanded the U.S. military leave Iraq** “amid a surge of anti-American sentiment” in Baghdad today, the [_Wall Street Journal_](https://www.wsj.com/articles/tens-of-thousands-march-in-baghdad-against-u-s-troops-in-iraq-11579860644?mod=hp_listb_pos3) reports from the Iraqi capital. Protesters shouted, “No, no to America! No, no to the occupation! No, no to corruption!” However, after just a few hours, "the protest mostly dissipated," [Reuters](https://www.reuters.com/article/us-iraq-security-sadr/no-no-america-iraq-protesters-demand-u-s-military-pullout-idUSKBN1ZN0RI) reports, "despite fears of violence following a cleric’s call for a 'million strong' turnout."

**_The cleric leading the call was Moqtada al-Sadr,_** “and the tone of the day was strictly nationalist,” the [_Washington Post_](https://www.washingtonpost.com/world/middle_east/iraqi-demonstrators-demand-withdrawal-of-us-troops/2020/01/24/b71de708-3df3-11ea-afe2-090eb37b60b1_story.html) reports. The [Associated Press](https://apnews.com/c2934966e27d5188f2419054db438aac) described the rally as “the cleric’s attempt to capitalize on brewing anti-American feeling and show he had the upper-hand on the Iraqi street as negotiations among political elites over who should be the next prime minister stumble on.”

**_Iraq’s leading Shiite cleric, Grand Ayatollah Ali Sistani,_** threw "his weight behind Friday’s march," too, the _Post_ writes. A statement from Sistani was reportedly "read aloud by a representative in the shrine city of Karbala \[declaring\] that Iraqi citizens have 'complete freedom' to peacefully demonstrate against anything that might undermine the country’s sovereignty."

**_Today, Sadr put forward “a list of conditions_** for American military presence in Iraq,” AP writes. “The list includes cancelling existing security agreements, closing U.S. military bases, ending the work of American security companies and closing off access to Iraqi airspace. If the conditions were met, the statement said, ‘the resistance will temporarily stop until the last soldier leaves Iraq.’”

**_For the record, the rockets have never really stopped._** In fact, they “have been fired at bases hosting troops from the U.S.-led coalition and into the heavily fortified Green Zone in Baghdad, where the American embassy is located, on five separate occasions in the weeks since \[Iranian\] Gen. Soleimani’s killing,” the _Journal_ reports. “No group claimed responsibility for those attacks, but Iran-backed militias are the prime suspect,” according to remarks Thursday from the White House’s special envoy for the coalition against Islamic State, James Jeffrey.

**_Don’t get it twisted: The U.S. will maintain its expanded Mideast presence_** — at least for now, CENTCOM’s Gen. Kenneth “Frank” McKenzie Jr., told sailors aboard the USS Bataan amphibious assault ship in the northern Red Sea on Thursday. 

**_“We’re in a very delicate time in the Central Command theater_** as a result of the events of the last couple of weeks,” McKenzie said, via the [_Washington Post_](https://www.washingtonpost.com/national-security/us-military-to-maintain-an-expanded-presence-in-the-mideast-following-iran-strikes-general-says/2020/01/23/4b1972e0-3e05-11ea-baca-eb7ace0a3455_story.html)’s Missy Ryan, who travelled with the general. “What we want to do is we want to convince the Iranians that now is not a good time to do something goofy.”

**_“Iran is very hard to read,”_** McKenzie added, according to [AP](https://apnews.com/2208d8645ac0437024ac71c06fcfb8e1)’s Lita Baldor, who is also traveling with the general. “So I would say the fact that things are quiet for a while does not mean that necessarily things are getting better.”

**_About U.S. readiness in CENTCOM’s AO:_** “The Bataan and two other U.S. warships moved into the Middle East on Jan. 11,” Baldor writes. “By Thursday, they were in the north Red Sea, roughly 50 miles south of the Sinai Peninsula. They are the latest additions to America’s troop presence in the region. Since May, their numbers have grown from about 60,000 to more than 80,000.”

**_Worth noting:_** “McKenzie did not say how long the U.S. military, which is looking to reorient its force toward challenges from China and Russia, would maintain its enhanced presence in the Middle East,” Ryan reported from the Bataan.

**_“Remember when the Trump Administration wanted to remove U.S. troops from the Middle East_** and focus on China and Russia?” RAND Corporation's [Becca Wasser](https://twitter.com/becca_wasser/status/1220488968220921856) tweeted after reading those reports. “I guess that didn’t go as planned. So would now be a good time to ask how \[National Defense Strategy\] implementation plans are going?” 

**_Related:_** “[Nearly half of Afghans want US troops out after Taliban peace deal](https://www.militarytimes.com/news/your-military/2020/01/23/survey-nearly-half-of-afghans-want-us-troops-out-after-taliban-peace-deal/),” AP reported Thursday off polling from the Kabul-based American Institute of War and Peace Studies. _Stars and Stripes_ has a bit more on that survey, [here](https://www.stripes.com/news/middle-east/few-us-voters-hopeful-about-afghan-peace-talks-poll-shows-1.616084). 

**_Read more on possible U.S. troop cuts_** elsewhere around the world below the fold… 

* * *

![D](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/static/a/newsletters/images/the-d-brief-d.png) From Defense One
------------------------------------------------------------------------------------------------------------------------

[**Security Clearance Backlog Hits Long-Awaited ‘Steady State’**](https://www.defenseone.com/threats/2020/01/security-clearance-backlog-hits-long-awaited-steady-state/162610/?oref=d_brief_nl) // Aaron Boyd, Nextgov: About 200,000 people are waiting for background investigations, which lawmakers called a welcome, sustainable level.

[**Global Business Brief**](https://www.defenseone.com/business/2020/01/global-business-brief-january-23-2020/162611/?oref=d_brief_nl) // Marcus Weisgerber: Pre-merger spinoffs; V-22 COD flies; Gremlins drone crashes, and more…

[**2020 Dems Need To Get Up To Speed on Nuclear Weapons. Fast.**](https://www.defenseone.com/ideas/2020/01/democratic-presidential-candidates-need-get-speed-nuclear-weapons-fast/162577/?oref=d_brief_nl) // Akshai Vikram: Front-runners have displayed key misunderstandings, while other candidates have shied away from the topic.

[**To Prove Trump’s Bad Faith, Don’t Argue Policy. Show He Subverted the Process.**](https://www.defenseone.com/ideas/2020/01/prove-trumps-bad-faith-dont-argue-policy-show-he-subverted-process/162600/?oref=d_brief_nl) // Scott R. Anderson: On Ukraine, the president dodged processes designed to ensure that U.S. foreign policy serves the public interest.

**Welcome to this Friday edition of** **_The D Brief_** from Ben Watson and Bradley Peniston. If you’re not already subscribed, you can do that [here](https://www.defenseone.com/f/the-dbrief-subscribe/). **_On this day in 1961,_** A B-52 bomber [broke up in midair](https://en.wikipedia.org/wiki/1961_Goldsboro_B-52_crash) and crashed in a North Carolina swamp. To date, only one of the two hydrogen bombs aboard has been recovered.

* * *

**SecDef Esper eyes SOUTHCOM for cuts.** Two weeks ago, Mark Esper [announced](https://www.defenseone.com/ideas/2020/01/esper-attempting-biggest-defense-reforms-generation/162457/?oref=d_brief_nl) that he would scrutinize various combatant commands, looking to trim their operating budgets and reduce their ability to demand forces of the service branches, all to focus the U.S. military’s attention more squarely on great-power competition. (Read: [Esper Is Attempting the Biggest Defense Reform in a Generation](https://www.defenseone.com/ideas/2020/01/esper-attempting-biggest-defense-reforms-generation/162457/) by AEI’s Mackenzie Eaglen.)  
**_U.S. Southern Command is now under that scrutiny,_** “raising the possibility that the already small Florida-based command could see additional cuts,” McClatchy’s Tara Copp [reports](https://www.mcclatchydc.com/news/nation-world/national/national-security/article239584858.html). But, she writes, this comes just as SOUTHCOM “is seeing a worrisome increase in Chinese and Russian investment, weapons sales and and influence in the command’s area of responsibility.”  
**_For example, said SOUTHCOM officials who asked to not be identified:_**

*   China has sent Venezuela weapons worth more than $615 million in the past decade.
*   Russian naval activity in the command’s area of responsibility is at a 15-year high. One Russian ship equipped to track and interfere with undersea data cables has loitered for months off the coast of Uruguay.

**_Pleading their case:_** SOUTHCOM officials noted that the command has seen “seven previous cuts” to staffing. “Ten years ago, if you came here, we had a Colombia division. A division of analysts working Colombia,” another Southern Command official said. “Right now we have two analysts working Colombia.”  
**_SOUTHCOM’s $1.2B budget_** is spent equally on security cooperation programs such as joint exercises, drug interdiction efforts, and headquarters support, a command spokesman said. Read on, [here](https://www.mcclatchydc.com/news/nation-world/national/national-security/article239584858.html).

**Philippines’ Duterte threatens to end U.S. military deal.** The United States has [denied entry](https://cnnphilippines.com/news/2020/1/22/ronald-bato-dela-rosa-united-states-visa.html) to [Roberto dela Rosa](https://www.bbc.com/news/world-asia-44598858), a key legislative ally of Philippine President Rodrigo Duterte and the former leader of an anti-drug campaign during which, human-rights groups [say](https://www.hrw.org/news/2020/01/22/us-revokes-visa-philippines-drug-war-police-chief), police extrajudicially shot thousands of people they accused of being involved in the drug trade.  
**_In response,_** Duterte [threatened on Thursday](https://www.aljazeera.com/news/2020/01/philippines-duterte-threatens-military-deal-200124000253473.html) to end the agreement under which U.S. troops visit the Philippines to help operate against extremists and exercise with the country’s military forces. He gave U.S. officials one month to reconsider theis visa decision. Read on, [here](https://www.aljazeera.com/news/2020/01/philippines-duterte-threatens-military-deal-200124000253473.html).

**China is racing to build a 1,000-bed hospital in 10 days** to try to contain the coronavirus epidemic with 830 confirmed cases (make that [881](https://www.wsj.com/articles/spreading-chinese-coronavirus-death-toll-rises-as-more-cities-are-locked-down-11579860808?mod=hp_lead_pos5)) and 26 dead across China, AP [reports](https://apnews.com/09be6cd295bc66a335e6686da6bbbffb) from Beijing. The new facility — under rapid construction [here](https://images.wsj.net/im-147013?width=1260&size=1.5) — is designed like the Xiaotangshan SARS hospital in Beijing, which "was built from scratch in 2003 in just six days to treat an outbreak of a similar respiratory virus that had spread from China to more than a dozen countries and killed about 800 people.”  
**_Otherwise, transportation has been halted in “at least 13 cities_** home to more than 36 million people. The cities are Wuhan, where the illness has been concentrated, and 12 of its neighbors in central China’s Hubei province.” Authorities in Jingzhou even set up body-temperature checkpoints at stations and highways throughout the city.   
**_“The vast majority of the victims had been older than 60,”_** the _Washington Post_ [reports](https://www.washingtonpost.com/world/coronavirus-china-live-updates/2020/01/24/4e678f9c-3e03-11ea-afe2-090eb37b60b1_story.html), “and almost all of them had existing health conditions.”  
**_There has been one confirmed case in the U.S.,_** and it “involves a Washington state man in his 30s who had recently traveled to Wuhan,” the _Wall Street Journal_ [reports](https://www.wsj.com/articles/what-we-know-about-the-wuhan-virus-11579716128?mod=article_inline).   
**_The cases present as “a fever,_** cough and other symptoms of pneumonia,” the _Journal_ writes in an explainer about the virus, which “can be spread by coughing, kissing or making contact with saliva.” Right now, “Five major airports in the U.S. are screening arriving international travelers for fever; those who have one are then screened for other symptoms.”   
**_The WHO says it’s still too soon to declare a global health emergency_** — a decision that’s drawn some criticism, as _The Daily Beast_ [reported](https://www.thedailybeast.com/chinas-coronavirus-keeps-spreading-but-the-world-health-organization-still-wont-declare-a-global-emergency?ref=home) Thursday.   
**_“Make no mistake. This is an emergency in China,”_** said WHO Director General Tedros Adhanom on Thursday, “but it has not yet become a global health emergency. It may yet become one… It is likely that we will see more cases in other parts of China and other countries.” 

**The Pentagon wants the U.S. to continue selling tech parts to Chinese firm Huawei,** the _Wall Street Journal_ reports. "Pentagon officials believe the change would harm U.S. companies, as do some officials at the Commerce Department," the _Journal_ writes.   
**_How this could harm American companies,_** according to the Pentagon: "Huawei is an enormous customer for U.S. high-tech firms. The semiconductor manufacturer Micron Technology Inc., for instance, said in its 2019 annual report that Huawei accounts for 12% of its revenue. If those companies can’t continue to ship to Huawei, Pentagon officials feared, the firms would fall behind economically and not have the funds to invest heavily in research and development, according to the people." Read on for what could come next, even though no U.S. officials seem to be talking at length just yet, [here](https://www.wsj.com/articles/pentagon-blocks-clampdown-on-huawei-sales-11579870801?mod=hp_lead_pos3).  
**_And one of the chief Huawei competitors, Swedish telecom Ericsson,_** is experiencing poor growth in North America, but that seems to be somewhat “offset by operators in Asia and the Middle East continuing to spend on 5G networks,” the _Journal_ [reports](https://www.wsj.com/articles/5gs-growing-costs-sting-swedish-telecom-giant-ericsson-11579867668?mod=hp_lista_pos5) separately this morning. 

**And finally this week:** **_The Guardian_** **has reportedly unmasked the leader** of the “U.S.-based neo-Nazi terror network the Base.” _The Guardian_’s Jason Wilson [reports](https://www.theguardian.com/world/2020/jan/23/revealed-the-true-identity-of-the-leader-of-americas-neo-nazi-terror-group?CMP=Share_iOSApp_Other) "The Base’s leader previously operated under the aliases 'Norman Spear' and 'Roman Wolf.’” But he “is in fact US-born Rinaldo Nazzaro, 46, who has a long history of advertising his services as an intelligence, military and security contractor. He has claimed, under his alias, to have served in Russia and Afghanistan.”  
**_Wilson’s reporting is supported by_** “freedom of information requests, the analysis of material provided to the _Guardian_ by a whistleblower inside the group, and cross-examination of information found online and in databases.”  
**_Nazzaro reportedly purchased “three 10-acre blocks of undeveloped land_** in Ferry County, Wash., which borders Canada, back in December 2018 for a cost of $33,000. The name of the buyer: a Delaware LLC called “Base Global.”   
**_The acquisition lines up with “a white supremacist strategy_** called the Northwest Territorial Imperative,” Wilson writes, “which was promoted by the deceased white supremacist Harold Covington. The strategy argues for the creation of a separatist ethnostate in the Pacific north-west and encourages white supremacists to move to the region.” The intrigue continues, [here](https://www.theguardian.com/world/2020/jan/23/revealed-the-true-identity-of-the-leader-of-americas-neo-nazi-terror-group?CMP=Share_iOSApp_Other).

**Have a safe weekend, everyone.** And we’ll see you again on Monday!


[Source](https://www.defenseone.com/threats/2020/01/34-injured-iran-attack-pentagon-now-says-it-launches-review-reporting-procedures/162640/)