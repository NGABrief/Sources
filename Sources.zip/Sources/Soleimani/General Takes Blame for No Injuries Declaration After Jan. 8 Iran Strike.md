# General Takes Blame for ‘No Injuries’ Declaration After Jan. 8 Iran Strike

> “I was never under any pressure at any time to shade this reporting,” CENTCOM’s Gen. Frank McKenzie told Congress. More than 100 troops later were diagnosed with TBI.

Shia militias backed by Iran carried out the rocket attack on Wednesday night that killed two Americans and one U.K. citizen at an Iraqi base north of Baghdad, senior Pentagon leaders said. 

“We do know that they are backed by Iran,” Defense Secretary Mark Esper told reporters at the Pentagon Thursday. “We know that much for sure.”

Speaking across town before the Senate Armed Services Committee, U.S. Central Command head Gen. Frank McKenzie pointed to the Shia militia group that attacked another Iraqi military base in December, killing an American contractor.

“The Iranian proxy group Kata'ib Hezbollah is the only group known to have previously conducted an indirect fire attack of this scale against U.S. and coalition forces in Iraq," McKenzie said, though he cautioned that the March 11 attack is still under investigation.

Joint Chiefs Chairman Gen. Mark Milley told reporters that the U.S. is looking at options to respond to what he called “a serious attack, a significant attack.” 

“We’re looking at everything,” he said. “We’ll await final options and decisions from the president.”

Esper would not rule out a direct attack on Iran, but he said that “we are focused on the group — groups — that we believe perpetrated this in Iraq as the immediate.”

Wednesday’s attack, a barrage of 18 Katyusha rockets, reignited tensions between Iran and the United States and raised profound questions about whether the Trump administration’s Iran strategy has done anything to discourage Tehran from targeting American interests. It comes just days after it [became public](https://www.wsj.com/articles/after-a-buildup-to-counter-iran-u-s-troops-begin-leaving-mideast-11583818501) that the U.S. had begun withdrawing backup forces it sent to the region to counter the threat from Iran — a signal that the Pentagon had thought tensions were declining. 

Iran and the United States came to the brink of war earlier in the year. After the Kata’ib Hezbollah attack killed the American contractor on Dec. 27, President Trump ordered the killing of Iranian Gen. Qassem Soleimani. Iran responded with a missile attack on another Iraqi air base, al Assad, leaving hundreds of U.S. soldiers with traumatic brain injuries. The United States declined to respond, and Pentagon officials and Republican lawmakers have boasted that the January killing had “reset deterrence” in the region, after months of rocket attacks from Iranian proxies and ship seizures in the Gulf.

But Wednesday’s attack “challenged the notion” that Iran has been cowed, the panel’s top Democrat, Sen. Jack Reed, R.I., said in his opening statement. McKenzie was pushed throughout the hearing to explain how the killing of Soleimani — controversial even at the time — could be said to have reset deterrence even as more Americans have now died at the hands of Iranian-backed proxies. 

“I believe we have reestablished a rough form of deterrence, what I would call contested deterrence with Iran at the level of state-on-state attacks,” McKenzie said. “By that I am referring to obviously attributable ballistic missile attacks from Iran launched on U.S. forces. I don’t think that’s an imminent threat.

“What has not been changed is their continuing desire to operate through their proxies indirectly against us. And that is a far more difficult thing to deter,” he said. 

Senior Trump administration leaders, most notably Secretary of State Mike Pompeo, have repeatedly said that the United States will hold Iran responsible for proxy attacks on Americans.

While some GOP lawmakers, such as committee chair Sen. Jim Inhofe, Okla., and Sen. Tom Cotton, Ark., said the killing of Soleimani reestablished deterrence, McKenzie’s answer failed to satisfy critical Democratic and Independent lawmakers. 

McKenzie argued that the fact that Iran is no longer harassing international ships in the Strait of Hormuz, as it had done last summer, is evidence that “state-on-state” deterrence has been reset. The killing of Soleimani, he said, put Tehran on notice that the Trump administration was willing to take serious action if Iran crossed an American red line.

"They have never doubted our capability. They have always doubted our will, and I think that gave them something to think about," McKenzie said. 

But direct “state-on-state” action has rarely been a feature in the decades of U.S.-Iran conflict since the toppling of the Shah, said Sen. Angus King, I-Maine.

“That’s not the issue,” King said. “It’s not been a state-on-state situation. The attacks have always been through proxies.” 

“Actually, Senator, on Jan. 7 we had a direct state-on-state attack,” McKenzie said, referring to the attack on al Assad.  

“After we killed Soleimani, correct?” King said pointedly. 

But McKenzie also said that he believed that the Jan. 7 would likely make it easier for Iran to attack the U.S. directly in the future.

“This state-sponsored missile-attack crossed a threshold compared to previous attacks and has probably set a lower bar for future actions by the regime,” he said. 

Milley, speaking to reporters at the Pentagon, declined to speculate on the timing of the March 11 attack, which occurred on Soleimani’s birthday. 

“There could be a lot of reasons,” he said. “It could be coronavirus, it could be rogue Shia militia groups, it could be Soleimani’s birthday. It could be a lot of things. Don’t know. 

“All we do know for certain is 12 to 18 107 rockets impacted on a base occupied by U.S. forces and two Americans are dead and one Brit’s dead and we have good indications of who did it.”

Among the many unknowns in the fraught dynamic between the two countries is the fact that both Washington and Tehran are battling outbreaks of the novel coronavirus. CENTCOM believes that the number of deaths inside Iran, which is seeing a massive outbreak, is underreported and will reduce the nation’s military readiness. (The virus has also infected some of their senior leaders.)

But the U.S. military is struggling with some of the same challenges. The commander of U.S. Army Europe is under a self-imposed quarantine after being exposed to the disease. And there are 90,000 Americans scattered throughout Central Command’s geographic area of responsibility. Iran, with its porous borders, has thousands of cases.

"Iran sits in the middle of the theater and their ability to pass that infection to other states is very worrisome,” McKenzie said.


[Source](https://www.defenseone.com/threats/2020/03/general-takes-blame-no-injuries-declaration-after-jan-8-iran-strike/163735/)