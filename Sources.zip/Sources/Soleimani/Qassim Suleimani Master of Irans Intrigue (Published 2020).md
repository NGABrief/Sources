# Qassim Suleimani, Master of Iran’s Intrigue, Built a Shiite Axis of Power in Mideast (Published 2020)

> The commander helped direct wars in Iraq, Syria, Lebanon and Yemen, and he became the face of Iran’s efforts to build a regional bloc of Shiite power.

The commander helped direct wars in Iraq, Syria, Lebanon and Yemen, and he became the face of Iran’s efforts to build a regional bloc of Shiite power.

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani/merlin_166595487_238d5e78-d351-4a65-b4ff-ce24e3f443bc-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

![Maj. Gen. Qassim Suleimani in 2016. He led the powerful Quds Force of the Islamic Revolutionary Guards Corps.](https://static01.nyt.com/images/2020/01/03/world/03suleimani/merlin_166595487_238d5e78-d351-4a65-b4ff-ce24e3f443bc-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Office of the Iranian Supreme Leader, via Associated Press

*   Published Jan. 3, 2020Updated Jan. 13, 2020

He changed the shape of the Syrian civil war and tightened Iran’s grip on Iraq. He was behind hundreds of American deaths in Iraq and waves of militia attacks against Israel. And for two decades, his every move lit up the communications networks — and fed the obsessions — of intelligence operatives across the Middle East.

On Friday, [Maj. Gen. Qassim Suleimani](https://www.nytimes.com/2020/01/07/world/middleeast/soleimani-funeral.html), the powerful and shadowy 62-year-old spymaster at the head of Iran’s security machinery, was killed by an American drone strike near the Baghdad airport.

Just as his accomplishments shaped the creation of a Shiite axis of influence across the Middle East, with Iran at the center, his death is now likely to prove central to a new chapter of geopolitical tension across the region.

[General Suleimani](https://www.nytimes.com/2020/01/07/world/middleeast/soleimani-funeral.html) was at the vanguard of [Iran’s](https://www.nytimes.com/2020/01/03/world/middleeast/suleimani-dead.html) revolutionary generation, joining the Islamic Revolutionary Guards Corps in his early 20s after the 1979 uprising that enshrined the country’s Shiite theocracy.

He rose quickly during the brutal Iran-Iraq war of the 1980s. And since 1998, he was the head of the Revolutionary Guards’ influential [Quds Force](https://www.nytimes.com/2020/01/03/world/middleeast/suleimani-dead.html), the foreign-facing arm of Iran’s security apparatus, melding intelligence work with a military strategy of nurturing proxy forces across the world.

![](https://static01.nyt.com/images/2020/02/02/us/03suleimani2/02iraq-airport-sub2-articleLarge-v2.jpg?quality=75&auto=webp&disable=upscale)

Image

![The remains of a vehicle hit by missiles outside the Baghdad airport on Friday.](https://static01.nyt.com/images/2020/02/02/us/03suleimani2/02iraq-airport-sub2-articleLarge-v2.jpg?quality=75&auto=webp&disable=upscale)

Credit...Iraqi Prime Minister Press Office, via Associated Press

Video

transcript

transcript

Video Shows Aftermath of U.S. Strike That Killed Top Iran Commander
-------------------------------------------------------------------

#### President Trump authorized the attack early Friday at Baghdad International Airport that killed Iran’s top security and intelligence commander, Maj. Gen. Qassim Suleimani.

Suleimani was plotting imminent and sinister attacks on American diplomats and military personnel. But we caught him in the act. We took action last night to stop a war. We did not take action to start a war.

![Video player loading](https://static01.nyt.com/images/2020/01/03/world/03iraq-briefing-span/merlin_166605342_bb1d07c1-25be-4a96-8815-857e98b24a47-videoSixteenByNine3000.jpg)

President Trump authorized the attack early Friday at Baghdad International Airport that killed Iran’s top security and intelligence commander, Maj. Gen. Qassim Suleimani.CreditCredit...Ali Mohammadi/Bloomberg News

But in Iran, many saw him as a larger-than-life hero, particularly within security circles. Anecdotes about his asceticism and quiet charisma joined to create an image of a warrior-philosopher who became the backbone of a nation’s defense against a host of enemies.

He was close to Iran’s supreme leader, Ayatollah Ali Khamenei, who on Friday issued a statement calling for three days of public mourning and “forceful revenge,” in a declaration that amounted to a threat of retaliation against the United States.

“His departure to God does not end his path or his mission,” he said.

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani8/merlin_166598637_34fd1e5c-a5e5-4dc2-85f3-b65a639b6aec-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Lebanese men waved a Hezbollah flag at the Lebanon-Israel border as they threw rocks at an Israeli Army vehicle on the Lebanon-Israel border in 2000.](https://static01.nyt.com/images/2020/01/03/world/03suleimani8/merlin_166598637_34fd1e5c-a5e5-4dc2-85f3-b65a639b6aec-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Lefteris Pitarakis/Associated Press

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani16/merlin_53487531_8869e863-ab75-46c7-8519-b79a6de3c2ea-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Fighters from the Free Syrian Army in Saqba, a town it controlled on the outskirts of Damascus, in 2012.](https://static01.nyt.com/images/2020/01/03/world/03suleimani16/merlin_53487531_8869e863-ab75-46c7-8519-b79a6de3c2ea-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Tomas Munita for The New York Times

The first years of General Suleimani’s tenure in the late 1990s were devoted to directing the militant group Hezbollah’s effort against the Israeli military occupation of south Lebanon. General Suleimani, along with Hezbollah’s military commander, Imad Mugniyah, drove a sophisticated campaign of guerrilla warfare, combining ambushes, roadside bombs, suicide bombers, targeted killings of senior Israeli officers and attacks on Israeli defense posts.

At the end, the price for Israel was too high, and in May 2000 it withdrew from Lebanon, marking a major victory for General Suleimani, his Quds Force and Hezbollah.

The Arab Spring in the Middle East, and later the fight against the Islamic State, turned General Suleimani from a shadow figure into a major player in the geopolitics of the region, said Tamir Pardo, a former head of Israel’s Mossad intelligence service.

“Suleimani’s professional life can be divided into two periods,” he said. “Until the Arab Spring, he is commander of a force that has branches in various parts of the world, active mainly in Syria, Lebanon and Iraq, but at the end of the day is a secret operational organization whose main purpose is terrorism.”

“From the shock that befell the Middle East following the rise of ISIS, he is changing course,” Mr. Pardo continued. “He becomes a kingpin regional player, knowing with great talent how to exploit the secret infrastructure he has established for so many years, to achieve noncovert objectives — to fight, to win, to establish presence.”

In recent years, the man whose face had rarely been seen became the face of Iran’s foreign operations.

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani4/merlin_84356203_626e4d3c-caf5-4032-8a66-b18058fefdcc-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Civilian volunteers during military training to assist Shiite militias loyal to Iran in Kufa, southern Iraq, in 2014.](https://static01.nyt.com/images/2020/01/03/world/03suleimani4/merlin_84356203_626e4d3c-caf5-4032-8a66-b18058fefdcc-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Lynsey Addario for The New York Times

![](https://static01.nyt.com/images/2020/02/02/world/03suleimani12/merlin_159390756_ef495108-4071-4831-8674-af2515bc5271-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![General Suleimani was one of the chief strategists on President Bashar al-Assad’s side in Syria’s civil war.](https://static01.nyt.com/images/2020/02/02/world/03suleimani12/merlin_159390756_ef495108-4071-4831-8674-af2515bc5271-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Meridith Kohut for The New York Times

In Syria, he oversaw a massive operation to shore up the government of President Bashar al-Assad, whose own troops had been depleted by widespread defections and fierce fighting with rebels seeking to topple the government since 2011. His command of Arabic helped put local commanders at ease as he welded them into a support network for Mr. al-Assad.

The Morning: Make sense of the day’s news and ideas. David Leonhardt and Times journalists guide you through what’s happening — and why it matters.

Over a number of years, Iranian operatives guided by General Suleimani recruited militia fighters from other countries — mostly from Iraq, Afghanistan and Pakistan — airlifting them into Syria to back up Mr. Assad’s forces in key battles.

Many of these militia fighters received training at military bases in Iran or on the ground in Syria by operatives from Lebanon’s Hezbollah, an organization General Suleimani had helped develop over the years.

When Iranian and Iranian-backed forces became major combatants against ISIS after the group took over roughly a third of Iraq in 2014, pictures of General Suleimani on the battlefield in fatigues began being widely shared on social media. The publicity spawned rumors that General Suleimani was trying to widen his fame for a possible run for Iran’s presidency; he denied them, saying he always saw himself as just a soldier.

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani5/03suleimani5-popup.jpg?quality=75&auto=webp&disable=upscale)

Image

![General Suleimani, left, in Tikrit, Iraq, in 2015.](https://static01.nyt.com/images/2020/01/03/world/03suleimani5/03suleimani5-popup.jpg?quality=75&auto=webp&disable=upscale)

Credit...SIPA, via Associated Press

That conflict, from 2014 through 2017, was a rare instance of Iran and the United States nominally fighting on the same side. On a number of occasions, Americans were hitting Islamic State targets from the air while General Suleimani was directing ground forces against the militants.

It was unclear what direct role General Suleimani played in Yemen. But Iran’s patronage of the country’s Houthi rebels, which intensified when Saudi Arabia intervened against them in Yemen’s war in 2015, had all the hallmarks of the Suleimani playbook: above all, to support local militants as a way of expanding Iranian influence and punishing Saudi Arabia, the region’s Sunni power.

Iran had long offered similar support to the Palestinian militant groups Hamas and Islamic Jihad, creating decades of new security headaches for Israel. And with the support of the Quds Force, Hamas was able to take over the Gaza Strip, capable of firing rockets that can reach into most of Israeli territory.

Previous American administrations had resisted striking General Suleimani directly, either because of operational concerns or out of fear that killing him could destabilize the region further and lead to [all-out war between the United States and Iran](https://www.nytimes.com/2020/01/03/world/middleeast/us-iran-war.html).

At least once, though, Israeli officials ran the possibility of attacking him up their command structure. That was in February 2008, while Israeli and American intelligence operatives were tracking Mr. Mugniyah, the Hezbollah commander, in the hopes of killing him, according to senior American and Israeli intelligence officials. Operatives spotted the Hezbollah commander talking with another man, who they quickly determined was Mr. Suleimani.

Excited by the possibility of killing two archenemies at once, the Israelis phoned senior government officials. But Prime Minister Ehud Olmert denied the request, as he had promised the Americans that only Mr. Mugniyah would be targeted in the operation.

Perhaps more than any other individual, General Suleimani was the foil for American plans in Iraq, which like Iran is predominantly Shiite.

After the United States invaded Iraq in 2003, Iranian militiamen and their Iraqi allies fought a clandestine war against American troops, launching rockets at bases and attacking convoys. The militias also played a large part in inflaming sectarian tensions that led to Iraq’s civil war in 2006 and 2007 between Shiites and Sunnis, leading President George W. Bush to order a troop surge there.

General Suleimani and other leaders of his generation were shaped by the brutal war between Iran and Iraq in the 1980s, a conflict so cruel, with trench warfare and chemical weapons, that some compared it to the devastation of World War I. Nearly a million people died on both sides, and General Suleimani spent much of that war on the front lines.

![](https://static01.nyt.com/images/2017/05/17/world/03suleimani17/Int-iran3sub-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Iraqi forces fired artillery on the outskirts of Khorramshahr, a major Iranian supply port, in 1980, during the Iran-Iraq war.](https://static01.nyt.com/images/2017/05/17/world/03suleimani17/Int-iran3sub-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Zuheir Saade/Associated Press

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani11/03suleimani11-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![General Suleimani, left, in 1982 during the Iran-Iraq war.](https://static01.nyt.com/images/2020/01/03/world/03suleimani11/03suleimani11-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...SIPA, via Associated Press

For him and his fellow soldiers, the war was a “never again” moment. Ensuring that Iraq was weak and unable to again pose a threat to Iran became the primary goal of Iran’s policy toward Iraq after the overthrow of Saddam Hussein, whom the United States supported during its war with Iran in the 1980s.

“For Qassim Suleimani, the Iran-Iraq war never really ended,” Ryan C. Crocker, a former American ambassador to Iraq, once said in an interview. “No human being could have come through such a World War I-style conflict and not have been forever affected. His strategic goal was an outright victory over Iraq, and if that was not possible, to create and influence a weak Iraq.”

Sometimes, American officials secretly communicated with General Suleimani in an effort to ease tensions in Iraq. In 2008, the American general, David Petraeus, was trying to find a truce in a fight that American forces and the Iraqi Army were waging against Shiite militias loyal to Iran. In Mr. Petraeus’s [telling of the story](https://www.theguardian.com/world/2011/jul/28/qassem-suleimani-iran-iraq-influence), he was shown a text message directed to him: “General Petraeus, you should know that I, Qassim Suleimani, control the policy for Iran with respect to Iraq, Lebanon, Gaza and Afghanistan.”

Years later, General Suleimani personally, and mockingly, addressed another American leader: President Trump, who in July 2018 warned Iran’s president not to threaten the United States.

“It is beneath the dignity of our president to respond to you,” General Suleimani declared in a speech in western Iran. “I, as a soldier, respond to you.”

“We are near you, where you can’t even imagine,” he added. “We are ready. We are the man of this arena.”

For years after the American invasion of Iraq in 2003, Iran railed against what it saw as American aggression in the region, worried that the United States would turn its attention to regime change in Iran after Mr. Hussein was gone.

American officials have blamed Iran for killing hundreds of American soldiers during the war, many with sophisticated, shaped-charge bombs that could slice through American armored vehicles.

As the United States sought to negotiate a deal with Iraq that would allow American forces to stay in the country past a 2011 deadline, it was General Suleimani who relentlessly pushed Iraqi officials to refuse to sign, using a mixture of threats and the promise of more financial and military aid, American and Iraqi officials say.

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani6/merlin_11221051_bc9eb2a2-7fd5-4cdb-ae33-a643d38e5caf-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![United States troops in Karbala, Iraq, in 2004.](https://static01.nyt.com/images/2020/01/03/world/03suleimani6/merlin_11221051_bc9eb2a2-7fd5-4cdb-ae33-a643d38e5caf-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Ashley Gilbertson for The New York Times

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani15/merlin_34841785_397624e9-9c47-4761-b2b8-365b9f5ccfa4-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![A demonstration against the United States in Najaf, Iraq, in 2010.](https://static01.nyt.com/images/2020/01/03/world/03suleimani15/merlin_34841785_397624e9-9c47-4761-b2b8-365b9f5ccfa4-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Joao Silva for The New York Times

On his orders, Iraqi construction crews in 2014 began building a roadway for Iranian supplies and militiamen, a small piece of what was perhaps the general’s most important project: establishing a land route from Tehran to the Mediterranean, across Iraq and Syria to Lebanon, where Iran has long supported Hezbollah, a primary threat to Israel.

One telling episode that illustrated the depth of Iranian control came in 2014, when the Islamic State was rampaging across Iraq. General Suleimani paid a visit to Bayan Jabr, then the country’s transportation minister.

According to a collection of Iranian intelligence cables [published recently](https://www.nytimes.com/interactive/2019/11/18/world/middleeast/iran-iraq-spy-cables.html) by The Intercept and The New York Times, General Suleimani came to Mr. Jabr with a demand: He needed to use Iraqi airspace to fly planeloads of military supplies to support the Syrian government of Mr. Assad. Despite lobbying by the Obama administration to close Iraq’s airspace to the flights, Mr. Jabr quickly said yes.

“I put my hands on my eyes and said, ‘On my eyes! As you wish!’” Mr. Jabr told an Iranian Intelligence Ministry officer, according to one of the cables. “Then he got up and approached me and kissed my forehead.”

The same trove of documents contains evidence that General Suleimani is not universally admired within Iran.

A bitter rivalry between his Quds Force and the other main Iranian intelligence agency, the Ministry of Intelligence, played out over the course of the cables. Many criticized General Suleimani’s proxy campaign in Iraq, and the way his militia allies abused the Sunni population there, as weakening Iran’s long-term interests in the region.

“This policy of Iran in Iraq has allowed the Americans to return to Iraq with greater legitimacy,” one cable read.

In others, ministry case officers portrayed General Suleimani as a relentless self-promoter who used the battle against the Islamic State to bolster his potential political aspirations in the future.

Iran watchers sounded alarm that General Suleimani’s death would unleash unpredictable regional mayhem from Syria to Iraq that would be difficult for the United States to contain. Several Iranian diplomats said that the prospect of diplomacy with the United States, being quietly negotiated through Japan and France, was effectively dead. The talk was now of revenge, not negotiations, they said.

“This one life lost will likely cost many more Iranian, Iraqi, American and others,” said Ali Vaez, director of Iran program for International Crisis Group. “It is not just Suleimani’s death, but likely the death knell of the Iran nuclear deal and any prospect of diplomacy between Iran and the U.S.”

Qassim Suleimani was born in 1957 in Rabor, in eastern Iran, and later moved to the city of Kerman. He was the son of a farmer, and began laboring as a construction worker at age 12. His highest level of education was high school, and he later worked in the municipal water department in Kerman, according to a profile published by the Iranian state media.

According to [a 2013 profile in The New Yorker](https://www.newyorker.com/magazine/2013/09/30/the-shadow-commander), General Suleimani’s father became burdened with debt under the Shah. When the revolution came he was sympathetic to the cause, and joined the Revolutionary Guards soon after. He was married and had children, although there were conflicting stories in the Iranian news media about how many.

Within Iran, he was widely seen as exerting more influence over the country’s foreign policy than even the country’s foreign minister, Mohammad Javad Zarif.

General Suleimani, in death if not in life, appeared to have united Iran’s rival political parties to rally behind the flag. Iran’s expansionist policies in Syria, Iraq and Lebanon have been contentious at home among ordinary Iranians and some reformist politicians who saw money and resources diverted from Iran to fund General Suleimani’s missions.

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani10/merlin_93743012_c94089f5-712f-4f0a-9066-512a933f4d40-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![General Suleimani, right, with Iran’s supreme leader, Ayatollah Ali Khamenei, at a religious ceremony in Tehran in 2015.](https://static01.nyt.com/images/2020/01/03/world/03suleimani10/merlin_93743012_c94089f5-712f-4f0a-9066-512a933f4d40-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Office of the Iranian Supreme Leader, via Associated Press

![](https://static01.nyt.com/images/2020/01/03/world/03suleimani12/merlin_124687307_8e0c3f9b-2303-4f4b-813f-e1140539bda5-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Portraits of Iranian supreme leaders Ayatollah Khomeini, right, Ayatollah Ali Khamenei, left, and the Iraqi cleric Muhammad Sadiq al-Sadr, center, in Baghdad in 2017.](https://static01.nyt.com/images/2020/01/03/world/03suleimani12/merlin_124687307_8e0c3f9b-2303-4f4b-813f-e1140539bda5-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Sergey Ponomarev for The New York Times

But on Friday, there was only praise and grief. Iranian officials across the political spectrum issued statements of condolences and condemned the United States.

The powerful Revolutionary Guards, of which the Quds Force is a component, said plans were underway for a huge public funeral.

“He was so big that he achieved his dream of being martyred by America,” wrote a reformist politician and former vice president, Mohammad Ali Abtahi.

General Suleimani had received the country’s highest military honor, the Order of Zolfaghar, established in 1856 under the Qajar dynasty. He became the only military commander to receive the honor in the Islamic Republic.

Ayatollah Khamenei pinned the medal on General Suleimani’s chest last February, and in remarks that now seem prophetic, said: “The Islamic Republic needs him for many more years. But I hope that in the end, he dies as a martyr.”

Tim Arango reported from Los Angeles; Ronen Bergman from Tel Aviv, Israel; and Ben Hubbard from Beirut. Nazila Fathi contributed reporting from Washington, and Farnaz Fassihi from New York.


[Source](https://www.nytimes.com/2020/01/03/obituaries/qassem-soleimani-dead.html)