# IAEA Director General's Introductory Statement to the Board of Governors

> Introductory Statement to the Board of Governors by IAEA Director General, Rafael Mariano Grossi.

Director General Rafael Mariano Grossi delivering his opening statement to the IAEA Board of Governors. (Photo: D. Calma/IAEA)

_(As prepared for delivery)_

Madam Chairperson,

Faced with the changing circumstances presented by COVID-19 throughout the past months, the Agency has adapted how it serves the Board and assists Member States. We continue to deliver our activities with minimal disruption, while fulfilling our duty to the health and wellbeing of staff.

​In line with the Austrian authorities’ latest guidelines, I have requested Departments organize their work to significantly reduce staff presence at the VIC while continuing to ensure programmatic deliveries.

I would like to once again voice my appreciation of the resilience of our staff and of the relevant divisions of the Agency who allow the IAEA to continue operating as normal as possible during these challenging times.

Following the meeting of the Technical Assistance and Cooperation Committee this week, I’d like to begin by reporting that the Agency is continuing to support Member States in the successful implementation of the Technical Cooperation (TC) programme.

Despite global travel constraints, TC programme delivery has carried on effectively throughout the year. Working in close consultation with you, our Member States, we have adjusted and prioritised project workplans.

I would like to thank Member States for their unwavering support of the Agency's TC activities. The technical cooperation programme is a major vehicle for the delivery of IAEA development support to Member States, and a core component of ‘Atoms for Peace and Development’.

Capacity building is a key focus.  Wherever possible, we have continued with physical in-person training, such as long-term fellowships. We have also moved a number of capacity-building events online, and we expect to implement postponed activities next year.

Looking ahead to the coming year, the top three TC priority areas for Member States are: food and agriculture, health and nutrition, and safety. We will also continue to provide Member States with assistance to address COVID-19, both through the ongoing emergency response activities, and through ZODIAC.

Agency support for COVID-19 has included nine informative videos on the use of RT-PRC for COVID, and 10 videos on the use of serology for COVID. They are available in English, Spanish, Russian, French, and Portuguese. A series of webinars related to RT-PCR has taken place in English, Spanish, Russian, and French. Six COVID-related publications have been published and several more are in the pipeline.

More than 1,873 consignments of equipment for virus detection and diagnosis and other supplies have been delivered, or are in transit, to 126 countries and territories. I am proud of the efforts of IAEA staff, who have gone the extra mile to make this happen, and grateful for the support of Member States, which made it possible. We have not defeated the pandemic yet and we need your support to help. I recognize the Kingdom of the Netherlands for its generous contribution of 1 million euros for the current Coronavirus assistance campaign.

The Agency has continued R&D activities through the veterinary laboratory VETLAB network to monitor variations in SARS-CoV2. The emergence of mutations and novel features, such as the infection found in minks recently highlights the need for constant monitoring and surveillance at the animal-human interface. Discussions took place with our counterparts in Denmark to share information and exchange technical expertise on the mink-associated variant strain. This is one of the main objectives of the ZODIAC project.

It is clear pandemics are a reoccurring global challenge and the IAEA must do its part to help Member States in detecting and mitigating them.

To that end, the Technical Assistance and Cooperation Committee (TACC) has recommended to the Board that it approve the proposed off-cycle TC project _Supporting National and Regional Capacity in Integrated Action for Control of Zoonotic Diseases_.

Zodiac is the way nuclear science, technologies and applications add value to the ongoing efforts by the international community to stop and defeat COVID-19 and prevent the next pandemic of zoonotic origin.

Zodiac is not more of the same, carried out by the IAEA in parallel with similar efforts elsewhere. Zodiac is the nuclear factor, in a winning international equation that builds on decade-long efforts by the Agency. In implementing Zodiac, the Agency will cooperate with sister organizations, as appropriate to achieve synergy in our respective deliveries to Member States.

I want to reassure Member States that we will provide adequate platforms to continue the process of information sharing and exchange of view on Zodiac. As in other important areas of our work, technical briefings will be organized at regular intervals to ensure that your views and suggestions are duly considered in a collaborative and transparent process.

Zodiac will be delivered and carried out efficiently, transparently and in a collaborative spirit, as required by the unique and global challenge we are all facing.

COVID-19 has not been the only emergency to which the TC programme has responded this year. In addition to our support to Lebanon in the aftermath of the explosion at the Port of Beirut, we are responding to requests for help in the wake of Hurricane Eta, which struck Central America early in November. We are assisting Central American nations through an expert mission and provision of equipment, initially to Honduras and Guatemala, with the possibility of extending our help to others in the region as even more storms loom.

Looking ahead, preparations for the 2022–2023 TC programme are well underway. Project proposals have been submitted and feedback is being provided to individual Member States.

The TC programme is an essential mechanism for the transfer of nuclear technology and human capacity building, which helps countries meet their development opportunities. For it to be able to fulfil its mandate and meet Member States’ expectations, on-time and complete contributions to the Technical Cooperation Fund are essential. As of 6th of November this year, we have reached a rate of attainment of 88.4%. I encourage all Member States to pay their contributions to the TCF in a timely manner, and I invite Member States that can do so to make extrabudgetary contributions.

I am particularly mindful of the increasing demands on the IAEA for support. Given the state of the global economy, my endeavour is to enlarge our donor base by forging new partnerships. We aim to tap into additional resources, including Development and Regional Banks, the private sector, interested foundations and others, so that the Agency is able to continue to provide meaningful support to Member States.

Madam Chairperson,

My report on _Verification and monitoring in the Islamic Republic of Iran in light of United Nations Security Council resolution 2231_ covers our activities in the last few months in verifying and monitoring Iran’s implementation of its nuclear-related commitments under the _Joint Comprehensive Plan of Action_.

Yesterday I also issued document GOV/INF/2020/16, which contains an update on those activities.

As you will recall, in August we reached agreement with Iran to reinforce cooperation and enhance mutual trust. The Agency, as agreed with Iran, has now conducted complementary accesses at two locations in Iran not declared to the Agency, and conducted an additional nuclear material inventory verification at a declared facility in Iran.

This important understanding, it must be recalled, was about procedural difficulties, not substance. Now it is essential to address and make progress in our verification work through sustained engagement and cooperation.

The Agency continues to verify the non-diversion of nuclear material declared by Iran under its Safeguards Agreement. The presence of multiple uranium particles of anthropogenic origin, including isotopically altered particles, at a location in Iran not declared to the Agency still needs to be fully and promptly explained by Iran to allay any possible concerns about the correctness and completeness of its safeguards declarations. Evaluations regarding the absence of undeclared nuclear material and activities in Iran continue.

Madam Chairperson,

The number of States with safeguards agreements in force has not changed since the last Board. It stands at 184, while 136 of these States have brought additional protocols into force.

I ask States Parties to the NPT without comprehensive safeguards agreements in force to bring such agreements into force without delay. I hope States that have not yet concluded additional protocols will do so as soon as possible. I also reiterate my call on States with small quantities protocols based on the old standard text, to amend or rescind them. This is essential to addressing a weakness in the IAEA safeguards system recognised by the Board 15 years ago. The old standard SQP is simply not adequate for our current safeguards system.

The Agency continues to monitor the nuclear programme of the Democratic People's Republic of Korea.

Since my report to the Board of 3rd of September 2020, some nuclear facilities in the DPRK continued to operate while others remained shut down. There are indications consistent with internal construction activities at the experimental light water reactor (LWR) and the production of enriched uranium. There were no indications of operation at the 5MW(e) nuclear reactor and the Radiochemical Laboratory.

The DPRK’s nuclear activities remain a cause for serious concern. The continuation of the DPRK’s nuclear programme is a clear violation of relevant UN Security Council resolutions and is deeply regrettable.

I call upon the DPRK to comply fully with its obligations under Security Council resolutions, to cooperate promptly with the Agency in the full and effective implementation of its NPT Safeguards Agreement and to resolve all outstanding issues, especially those that have arisen during the absence of Agency inspectors from the country.

The Agency is intensifying its readiness to play its essential role in verifying the DPRK’s nuclear programme.

As far as implementation of safeguards in the Syrian Arab Republic is concerned, no new information has come to the knowledge of the Agency that would affect our assessment that it was very likely that the building destroyed at Dair Alzour was a nuclear reactor that should have been declared by Syria. This was almost ten years ago.

I urge Syria to cooperate fully with the Agency in connection with all unresolved issues. I am ready to talk to Syria constructively and cooperatively. Let us engage to take concrete steps towards a mutually acceptable solution to this matter that has been on the Board’s agenda for a very long time.

Madam Chairperson,

Turning now to nuclear energy. The 442 nuclear power reactors operating in 32 countries today provide more than 392 gigawatts of installed capacity, supplying over 10% of the world’s electricity and around a third of all low-carbon electricity. There are 53 reactors under construction in 19 countries, which are expected to provide 56 gigawatts of additional capacity.

Belarus, which has worked closely with the Agency in developing the necessary infrastructure for new nuclear power programmes, this month connected its first nuclear power reactor to the electrical grid. This comes after the United Arab Emirates recently connected the first of four planned reactors to the grid. Both these examples represent major milestones that underscore the continued interest in nuclear power among our Member States.

In terms of Low Enriched Uranium (LEU) assurance of supply, a contract with the China Nuclear Energy Industry Corporation (CNEIC) concerning the transport of LEU and/or equipment necessary for the operation of the IAEA LEU Bank, was signed in September. It provides for a second route of transport to and from the IAEA LEU Bank in Kazakhstan.

Last month, more than 680 participants from 105 Member States gathered online for two weeks for the _International Conference on the Management of Naturally Occurring Radioactive Material (NORM) in Industry_. It was the IAEA’s first international conference on this topic and first completely virtual conference. Participants recognized that industry must be fully part of the conversation if safe and cost-effective solutions for NORM are to be put in place.

Madam Chairperson,

Regarding nuclear safety and nuclear security, I am pleased to report that the ongoing virtual _International Conference on Radiation Safety: Improving Radiation Protection in Practice_ has more than 2,000 registered participants attending sessions covering a broad spectrum of radiation safety issues. This conference hosted a series of side events organized for young professionals. These events generated strong interest, garnering more than 400 registrations. Youth and science play important, inter-locking roles in achieving the mandate and goals of the IAEA, now and in the future.

I would also like to draw your attention to the 2021 _International Conference on a Decade of Progress after Fukushima-Daiichi: Building on the Lessons Learned to Further Strengthen Nuclear Safety_, for which preparations are well under way.

This high-level event, scheduled to take place the 22nd to the 26th of February, public health circumstances permitting, will serve as an opportunity to reflect on the lessons learned in the past ten years and the future course of action in this important area of the Agency’s work. I encourage all Member States actively to participate.

Another noteworthy virtual event, which is taking place from the 7th to 11th of December, is the _Meeting of the Preparatory Committee (PrepCom) for the 2021 Conference of the Parties to the Amendment to the Convention on the Physical Protection of Nuclear Material (CPPNM)_. The purpose of this meeting is to undertake formal preparations for the 2021 Conference. We continue to encourage universal adherence to and effective implementation of the CPPNM and its 2005 Amendment and can provide technical and legislative assistance upon request.

Nuclear law is an essential part of the global nuclear framework. I have therefore decided to convene the Agency’s first international conference on the subject. It is scheduled to take place at Headquarters from the 7th to the 11th of February 2022. The conference will provide a unique forum for leading global experts from government, industry, academia and civil society, to share experiences and debate topical issues. I expect this event to reaffirm the IAEA as the global platform for nuclear law.

Madam Chairperson,

This year marks the 10th anniversary of the Peaceful Uses Initiative. Through more than 174 million euros of funding, the PUI has supported in excess of 300 projects benefitting more than 150 Member States. I welcome the US’s pledge of 50 million dollars over the coming five years and invite others to follow suit in supporting the PUI.

Here in Austria, the successful completion of all new facilities launched to date under the ReNuAL/ReNuAL+ initiative has significantly strengthened the capacity of our Nuclear Applications laboratories in Seibersdorf.

We are on track to launch construction next year for ReNuAL 2, which will greatly enhance the Agency’s ability to support Member States in the areas ranging from climate-smart agriculture to food security, and from environmental management to cancer treatment.

I am thankful for Member States’ strong support, which has brought us so far, and I am grateful that the United States has already kickstarted the process by contributing more than 5 million euros to help launch ReNuAL 2. I urge other Member States to follow suit and help us crown this phase of the project with the same success as the previous one.

The ReNuAL project has had considerable success obtaining private sector support through cost-free loans and donations of equipment in order for the NA Laboratories to meet the evolving needs of Member States. As part of resource mobilization efforts in support of ReNuAL 2, an updated list of required equipment will be published on the United Nations Global Marketplace (UNGM) portal in December 2020. Member States are encouraged to highlight this opportunity to manufacturers in their respective countries.

In terms of security training, I would like to add that a nuclear security training and demonstration centre is being established at the Seibersdorf laboratories. It is part of the Multipurpose Building (MPB) project and is being closely coordinated with other projects. We are confident that the Centre will provide additional capacity for the IAEA to provide training and development in support of sustainable nuclear security initiatives and their effective implementation. The Agency has received, with gratitude, financial commitments to establish the Centre from partners led by Saudi Arabia, the UK and the US. We would welcome further financial commitments for its operation and sustainability.

Madam Chairperson,

In nuclear laboratories far beyond Seibersdorf and out in the field, our sector remains one bereft of female talent. That is why I am pleased to report that more than 550 candidates from more than 90 countries submitted applications to the first cycle of the IAEA’s Marie Sklodowska‑Curie Fellowship Programme. The 100 selected fellows come from 71 Member States and all world regions. Their studies cover a wide range of nuclear related subjects, from nuclear engineering to nuclear medicine, and from nuclear security to non-proliferation and nuclear law.

The programme has received more the 5 million euros in pledges.  I am grateful and proud of this support and I encourage other Member States to join the initiative.

Madam Chairperson,

The Agency’s Programme & Budget for 2022-2023 is being prepared while fully taking into account the environment in which we operate. This includes the consideration of the financial constraints of Member States, which have been exacerbated by the COVID-19 crisis and the ever-increasing workload of the Agency. I have made clear to all my managers that we must manage the resources that Member States entrust to us wisely and productively, and with discipline and restraint. To that end, the 2022-2023 Programme & Budget is prepared with a strong focus on finding sustainable efficiencies and ensuring the effectiveness of our activities.

For the first time, I have set financial targets for efficiencies. These savings will enable the Agency to accommodate Member States’ increased demand for its services, without the regular budget growing in line with our expanding responsibilities. The Agency’s Draft Programme & Budget for 2022-2023 will be issued by the end of January 2021 and I look forward to constructive discussions with you. Madam Chairperson, you have my assurances that I am engaged and committed to ensuring a transparent process.

Madam Chairperson,

With my final words, I would like to thank four colleagues who will be leaving the Agency soon.

I know you will all want to join me in wishing Ambassador Aruni Wijewardane well and thanking her personally for her long service to the IAEA. Her dedication and professionalism will be missed, not only by the Agency staff but also by Member States. She is one of the more familiar faces to all delegates and as Secretary of the Policy-Making Organs guided successive Chairpersons of the Board of Governors and Presidents of the General Conference with impeccable professionalism and gentleness. I thank her and wish her well for the future.

Secondly, I would like to thank Salwa Dallalah, our departing director of Conference and Document Services, another key area of our work. Salwa has been an experienced and wise collaborator and I wish her all the very best.  Our appreciation also goes to Raja Abdul Aziz Raja Adnan, Director of the IAEA’s Division of Nuclear Security, who ably navigated the challenges and opportunities of his division. An experienced and respected professional, he allowed the Agency to fulfil its growing responsibilities in this field actively and systematically. I thank him and wish him the best.

And it is with respect that we bid farewell to Dazhu Yang, the IAEA’s distinguished Deputy Director General for Technical Cooperation. I’d like to express my personal gratitude for his considered leadership and valuable contribution to this important area of the Agency’s mandate. I much appreciated his advice and guidance during my first year in office.

Thank you.


[Source](https://www.iaea.org/iaea-director-generals-introductory-statement-to-the-board-of-governors-18-november-2020)