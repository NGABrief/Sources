# Iran Enriches Uranium to Higher Levels

> January/February 2021
By Kelsey Davenport

  
January/February 2021  
By [Kelsey Davenport](https://www.armscontrol.org/about/Kelsey_Davenport)

Iran began enriching uranium to a higher purity level in January, despite warnings from European countries that taking such a step would jeopardize efforts to preserve the 2015 nuclear deal.

![IAEA Director-General Rafael Mariano Grossi announced on Jan. 11 that Iran was enriching uranium to 20 percent "quite rapidly." (Photo: Dean Calma/IAEA)](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/sites/default/files/images/ACT_Photos/2021_01/18_News_ACTJanFeb21_Iran.png)

IAEA Director-General Rafael Mariano Grossi announced on Jan. 11 that Iran was enriching uranium to 20 percent "quite rapidly." (Photo: Dean Calma/IAEA)

Iranian government spokesman Ali Rabiyee said on Jan. 4 that “the process of \[uranium\] gas injection started” at the Fordow facility and that the first “product will come out within a few hours.”

The International Atomic Energy Agency (IAEA) confirmed that same day that Iran began enriching uranium to a level of 20 percent uranium-235 at the Fordow facility and had notified the agency of its intention to do so in advance, consistent with its past breaches.

IAEA Director-General Rafael Mariano Grossi said on Jan. 11 that Iran’s enrichment of uranium to 20 percent was proceeding “quite rapidly” and could likely produce about 10 kilograms of uranium enriched to that level every month.

Enriching uranium to 20 percent is a significant violation of the nuclear deal, known as the Joint Comprehensive Plan of Action (JCPOA), which limits Iran to uranium enrichment up to 3.67 percent U-235. Iran breached that restriction slightly beginning in July 2019, when it ratcheted up enrichment to 4.5 percent U-235 in response to the Trump administration’s sanctions campaign. (See ACT, July/August 2019.)

A law enacted on Dec. 28 mandated that Iran produce 120 kilograms of uranium enriched to 20 percent every year. The bill passed despite the objections of Iranian President Hassan Rouhani, who described it as narrowing the space for future diplomacy.

France, Germany, and the United Kingdom issued a statement Dec. 7 warning Iran against following through on the activities specified in the nuclear law, saying that if Tehran “is serious about preserving a space for diplomacy, it must not implement these steps.”

They said such action “would jeopardize our shared efforts to preserve the JCPOA and risks compromising the important opportunity for a return to diplomacy with the incoming U.S. administration.”

Iran produced 20 percent-enriched uranium prior to negotiations on the JCPOA. Under the deal, Iran is prohibited from enrichment activities at Fordow and is limited to enriching uranium to 3.67 percent for 15 years. Twenty percent-enriched uranium poses a more significant proliferation risk because it constitutes about 90 percent of the required work to enrich uranium to weapons grade, which is uranium enriched to greater than 90 percent U-235.

Despite the move, officials in Tehran, including Supreme Leader Ali Khamenei, continue to signal that Tehran is open to returning to compliance with the accord if the United States does likewise. Khamenei said on Dec. 16 that Iran “should not hesitate for even an hour” if sanctions can be lifted in a “correct, wise” manner.

The law does say that the required actions can be suspended if certain sanctions relief envisioned by the nuclear deal is granted.

U.S. President Joe Biden has made clear his intention to return the United States to compliance with the JCPOA, alongside Iran. President Donald Trump withdrew the United States from the JCPOA in May 2018 and reimposed sanctions on Iran.

In a Dec. 2 interview with _The New York Times_, Biden reaffirmed his intention to return the United States to the JCPOA if Iran adheres to its obligations. He said the best way to achieve getting some stability in the region” is to deal “with the nuclear program” first.

Biden’s plan to rejoin the JCPOA and use it as a basis for further diplomacy with Iran differs significantly from the Trump administration’s approach, which relied on sanctions pressure to try and push Iran to negotiate a more comprehensive agreement.

U.S. Secretary of State Mike Pompeo condemned Iran’s nuclear law in a Dec. 11 statement, describing it as a “ploy to use its nuclear program to try to intimidate the international community.” He said countries “must not reward the regime’s dangerous gamesmanship with economic appeasement.”

The law would also require Iran to halt implementation of the more intrusive inspections in the additional protocol to its safeguards agreement, enrich uranium using at least 1,000 advanced IR-2m centrifuges at the Natanz facility within three months, complete the Arak heavy-water reactor, construct a new heavy-water reactor, and inaugurate a uranium-metal facility within five months.

Iran notified the IAEA on Dec. 2 that it intends to install additional advanced IR-2 centrifuges at Natanz.

Despite passage of the legislation, Iran in a Dec. 21 joint statement with the remaining parties to the JCPOA (China, France, Germany, Russia, the UK, and the EU) reiterated that the “full and effective implementation of the JCPOA by all remains crucial.”

The statement, which was released after a ministerial meeting of the Joint Commission, the body set up to oversee implementation of the JCPOA, “acknowledged the prospect of a return” of the United States to the JCPOA and “underlined their readiness to positively address this in a joint effort.”


[Source](https://www.armscontrol.org/act/2021-01/news/iran-enriches-uranium-higher-levels)