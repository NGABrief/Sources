# Iran nuclear deal: IAEA finds uranium particles at undeclared site

> International inspectors are reported to have taken samples from a Tehran location identified by Israel.

Published

11 November 2019

![Benjamin Netanyahu holds a picture of what he described as "Iran's secret atomic warehouse" in Tehran's Turquzabad district (27/09/18)](https://ichef.bbci.co.uk/news/976/cpsprodpb/9D4F/production/_109617204_gettyimages-1042114014-1.jpg)image copyrightGetty Images

image captionIsrael's prime minister said last year that 15kg of radioactive material was removed from a site in Turquzabad

**The International Atomic Energy Agency (IAEA) has found uranium particles at a site in Iran that had not been declared by the Iranian authorities.**

A confidential report, seen by the BBC, did not say exactly where the site was. But inspectors are believed to have taken samples from a location in Tehran's Turquzabad district.

That is the area where Israeli Prime Minister Benjamin Netanyahu has alleged Iran had a "secret atomic warehouse".

Iran has not responded to the report.

But it has previously said the site was a carpet cleaning factory and served no clandestine purpose.

The IAEA's report also confirmed Iran had resumed uranium enrichment at its underground Fordo facility, breaching another commitment under its landmark 2015 nuclear deal with world powers. Enriched uranium can be used to make reactor fuel but also nuclear weapons.

Three world powers party to the accord - France, the UK, and Germany - said they were "extremely concerned" by Iran's decision and warned that it made their efforts to defuse tensions in the region more difficult.

media captionInside Iran: Iranians on Trump and the nuclear deal

Iranian President Hassan Rouhani said last week that it was responding to the sanctions that were reinstated by the US when President Donald Trump abandoned the deal last year and have caused its oil exports to collapse.

The 2015 deal saw Iran, which insists its nuclear programme is entirely peaceful, agree to limit its sensitive activities and allow in IAEA inspectors in return for the lifting of crippling economic sanctions.

Mr Trump wants to force Iran to negotiate a new agreement that would place indefinite curbs on its nuclear programme and also halt its development of ballistic missiles. But Mr Rouhani has so far refused.

The IAEA report said its inspectors had "detected natural uranium particles of anthropogenic origin at a location in Iran not declared to the agency".

"It is essential for Iran to continue interactions with the agency to resolve the matter as soon as possible," the report added.

![File photo of the headquarters of the International Atomic Energy Agency (IAEA) in Vienna, Austria (20 June 2019)](https://ichef.bbci.co.uk/news/976/cpsprodpb/EB6F/production/_109617206_79726d46-b001-40de-a835-29c3aa1ffe0e.jpg)image copyrightReuters

The report did not say where the particles were found, but three senior Israeli security and intelligence officials told a briefing last Thursday that inspectors had visited the site in Turquzabad earlier this year and taken environmental samples.

The Israeli officials claimed the tests showed that uranium had been stored at the site, but not in a form that could yet be used for a weapon. The BBC understands the uranium was not enriched.

During a speech at the UN in September 2018, [Israeli Prime Minister Netanyahu showed photos of a complex in Turquzabad](https://mfa.gov.il/MFA/PressRoom/2018/Pages/PM-Netanyahu-addresses-UN-General-Assembly-27-September-2018.aspx), which he said was a "a secret atomic warehouse for storing massive amounts of equipment and materiel from Iran's secret nuclear weapons program".

Mr Netanyahu said the Iranian authorities had removed 15kg (33lb) of radioactive material from the warehouse the previous month and "spread it around Tehran in an effort to hide the evidence".

Iran's foreign ministry said the speech was "false, meaningless and unnecessary".

![Changes agreed under Iran deal to limit nuclear programme](https://ichef.bbci.co.uk/news/640/cpsprodpb/86DB/production/_109532543_iran_nuclear_sites_v5_640map-nc.png)

![Presentational white space](https://ichef.bbci.co.uk/news/624/cpsprodpb/94C2/production/_109028083_1px_white_line-nc.png)

"They put gravel on it to try to hide their traces. But they didn't," he added. "The IAEA found traces of uranium that Iran hid in these sites. That's a direct violation of the NPT, the \[nuclear\] Non-Proliferation Treaty."

He spoke after acting IAEA Director General Cornel Feruta stressed the need for Iran to "respond promptly to agency questions related to the completeness of Iran's safeguards declarations".

Iran's Foreign Minister, Mohammad Javad Zarif, rejected the Israeli claims, tweeting: "The possessor of REAL nukes cries wolf—on an ALLEGED 'demolished' site in Iran."


[Source](https://www.bbc.com/news/world-middle-east-50382219)