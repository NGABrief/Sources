# Iran and the crisis in the Gulf explained

> Tankers, drones and fears of war. What's the crisis in the Gulf about?

![Image from video provided by Iranian Revolutionary Guards Corp website purporting to show Iranian forces boarding the British-flagged tanker Stena Impero on 20/07 19](https://ichef.bbci.co.uk/news/976/cpsprodpb/18444/production/_107969399_8957928f-6206-4d94-b067-70feb07550a1.jpg)image copyrightAFP

image captionIran's seizure of a British-flagged tanker followed the detention of an Iranian tanker off Gibraltar

**A crisis has erupted between Iran and Western countries - in particular the UK and US - after a series of incidents in and around the Gulf, a strategically important waterway in the Middle East. Both sides are blaming the other and there are fears it could lead to war.**

What is the crisis about?
-------------------------

Behind the latest tensions is the fact that Iran and the US have increasingly accused each other of aggressive behaviour.

The US says recent activity by Iranian and Iranian-backed forces is destabilising the region and threatening US interests, while Iran says the US is trying to use military force and economic pressure to bring down its government.

The crisis really began to escalate in May when four oil tankers were were hit by blasts in the Gulf of Oman. Iran denied US accusations its forces had planted mines on the vessels.

Since then, two more tankers have been attacked, the US and UK have bolstered their naval forces in the region, and the US and Iran have said they have shot down each other's drones.

On 4 July, Iran seized a British-flagged tanker in the Strait of Hormuz, apparently in retaliation for the detention of one of its own tankers by British forces off Gibraltar. [The Iranian tanker was released six weeks later](https://www.bbc.co.uk/news/world-europe-49390902).

Why does the crisis matter?
---------------------------

What is going on involves some of the Gulf region's most powerful countries, as well as the world's most powerful military - that of the US.

Beyond that, the tensions threaten the use of the Strait of Hormuz. Almost a fifth of the world's oil passes through the narrow strait, which lies off the south coast of Iran.

media captionWhy does the Strait of Hormuz matter?

If international shipping is hampered or even blocked there, the economic effects will be felt around the globe. They could include a sharp increase in oil prices.

And if the crisis erupts into a war, the consequences will be devastating.

Why is this happening now?
--------------------------

The tensions in the Gulf can be traced to the resurgence of another crisis - that over Iran's nuclear programme.

For years, the international community and Iran were at loggerheads over the country's nuclear activities, amid suspicions that it was trying to develop nuclear weapons. Iran has always denied this, asserting that its programme was solely peaceful.

An agreement was reached in 2015, whereby Iran agreed to limit its nuclear activities in return for the lifting of economic sanctions. But last year, US Donald Trump pulled out of the deal, saying it was flawed. He reinstated sanctions on Iran and has continued to tighten them, hitting the Iranian economy hard.

Iran has been outraged by the US move, accusing it of violating the agreement. It has ceased abiding by several key nuclear commitments and threatened to do more unless European countries still party to the deal do something, and quickly, to mitigate the effects of the US sanctions.

media captionInside Iran: Iranians on Trump and the nuclear deal

Observers have speculated that the attacks on the tankers around the Gulf might be a signal by Iran that it is capable of disrupting shipping there if European powers do not act.

What's it all got to do with the UK?
------------------------------------

To begin with, it was really on the sidelines as the US and Iran shadow-boxed in the Gulf.

But then British Royal Marines helped detain an Iranian tanker in waters off the British overseas territory of Gibraltar in early July, after Gibraltar's government said it believed the tanker was transporting oil to Syria in violation of EU sanctions.

Iran reacted furiously to what it said was an act of piracy by British forces. [It threatened to seize a British tanker](https://preview.api.bbc.co.uk/news/uk-48882455) unless the Iranian tanker was released.

media captionA Royal Navy frigate can be heard warning Iranian armed forces, before the oil tanker is seized

The UK subsequently deployed an additional warship to the Gulf to protect British shipping.

Iran is still holding both the ship and its 12-strong crew, sharply heightening the crisis.

![map](https://ichef.bbci.co.uk/news/640/cpsprodpb/032D/production/_107931800_strait_of_hormuz_larak_640map-nc.png)

![Presentational white space](https://ichef.bbci.co.uk/news/624/cpsprodpb/17B75/production/_105914179_blank_white_space-nc.png)


[Source](https://www.bbc.com/news/world-middle-east-49069083)