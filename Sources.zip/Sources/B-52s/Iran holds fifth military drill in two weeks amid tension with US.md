# Iran holds fifth military drill in two weeks amid tension with US

> Iran showcases special forces, helicopters and tanks after the US flies B-52 bombers over the Middle East again.

Iran showcases special forces, helicopters and tanks after the US flies B-52 bombers over the Middle East again.

**Tehran, Iran –** Iran’s army has conducted another drill along the country’s southern coasts days after the United States flew nuclear-capable B-52 bombers over the Middle East.

In what is the fifth military show of force in two weeks, the army’s ground forces held land, air, and sea war games along the coast of Makran and the Sea of Oman.

State broadcaster aired dramatic footage of dozens of Iranian soldiers parachuting out of aeroplanes while images released by the army show attack helicopters, tanks and missiles in combat, and hundreds of personnel ready to be deployed.

The army also said it is deploying rapid response forces to test out “a variety of creative indigenous tactics” and is using divers to complete predefined scenarios.

“Today, army ground forces have achieved considerable operational capabilities in deploying drones and missiles,” said Brigadier General Mohammad Hossein Dadras, deputy chief of the Iranian army.

![](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/wp-content/uploads/2021/01/photo_2021-01-19_08-48-13.jpg?w=770&resize=770%2C513)On Sunday, Iran’s Foreign Minister Mohammad Javad Zarif condemned the B-52 mission \[Iran army handout\]

“The power and might of the army’s ground forces in responding to threats will be displayed in this exercise.”

The drill came days after the US once more flew B-52 bombers over the region, the fifth time in the past two months.

The outgoing Donald Trump administration, which has pursued a “maximum pressure” policy accompanied with harsh economic sanctions on Iran, first flew the bombers in the run-up to the January 3 anniversary of the assassination of Iran’s top general Qassem Soleimani.

Soleimani was killed in a Trump-ordered drone strike in Baghdad last year.

In response to the increased US military presence, Iran’s army and the Islamic Revolutionary Guard Corps (IRGC) have organised several military shows of force in the new year.

The army conducted a drill for locally made drones and fired torpedoes from locally made submarines, while the IRGC unveiled a huge underground missile base and tested long-range missiles that it said could take out enemy vessels and aircraft carriers more than 1,800km (1,118 miles) away.

![](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/wp-content/uploads/2021/01/photo_2021-01-19_08-10-27.jpg?w=770&resize=770%2C513)In a speech on Tuesday, IRGC commander-in-chief Hossein Salami said the war games bring ‘calm and confidence’ for the Iranian people \[Iran army handout\]

On Sunday, Iran’s Foreign Minister Mohammad Javad Zarif condemned the B-52 mission, saying the US should spend its military billions “on your taxpayers’ health” if it meant to intimidate Iran.

“While we have not started a war in over 200 years, we don’t shy from crushing aggressors,” he said.

In a speech on Tuesday, IRGC commander-in-chief Hossein Salami said the war games bring “calm and confidence” for the Iranian people and signal that Iran will not falter in defending itself.

“Our hands are on the trigger in representation of the great Iranian nation,” he said.

US President-elect Joe Biden, who will replace Trump on Wednesday, has promised to ease tensions with Tehran by revitalising the 2015 nuclear deal from which Trump unilaterally withdrew in 2018.

Biden has, however, signalled that Washington looks for broader negotiations over Iran’s missiles programme and its regional influence, something Iran has rejected.

![](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/wp-content/uploads/2021/01/2_27_resize.jpg?w=770&resize=770%2C513)The army said it is deploying rapid response forces to test out “a variety of creative indigenous tactics” \[Iran army handout\]


[Source](https://www.aljazeera.com/news/2021/1/19/irans-army-holds-war-games-again-after-us-flies-bombers)