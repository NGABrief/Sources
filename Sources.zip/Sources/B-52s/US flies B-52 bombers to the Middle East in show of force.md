# US flies B-52 bombers to the Middle East in show of force

> The US military flew nuclear-capable B-52 bombers to the Middle East Wednesday "to underscore the US military's commitment to regional security and demonstrate a unique ability to rapidly deploy overwhelming combat power on short notice," according to a statement from US Central Command, which oversees military operations in the region.

### Do Not Sell My Personal Information

For California Residents Only  
Pursuant to the California Consumer Privacy Act (CCPA)

The WarnerMedia family of brands uses data collected from this site to improve and analyze its functionality and to tailor products, services, ads, and offers to your interests. Occasionally, we do this with help from third parties using cookies and tracking technologies.

We respect your right to privacy, and we have built tools to allow you to control sharing of your data with third parties. You can choose to disable some types of cookies and opt to stop sharing your information with third parties, unless it is necessary to the functioning of the website. Click on the different category headings to find out more and to opt-out of this type of data sharing. Note that any choice you make here will only affect this website on this browser and device.

To learn more about how your data is shared and for more options, including ways to opt-out across other WarnerMedia properties, please visit the [Privacy Center.](https://www.warnermediaprivacy.com/do-not-sell/)

### Manage Consent Preferences

Share my Data with 3rd Parties

For California Residents Only

Pursuant to the California Consumer Privacy Act (CCPA)

Some of your data collected from this site is used to help create better, more personalized products and services and to send ads and offers tailored to your interests. Occasionally this is done with help from third parties. We understand if you’d rather us not share your information and respect your right to disable this sharing of your data with third parties for this browser, device, and property. If you turn this off, you will not receive personalized ads, but you will still receive ads. Note that any choice you make here will only affect this website on this browser and device.

To learn more about how your data is shared and for more options, including ways to opt-out across other WarnerMedia properties, please visit the [Privacy Center](https://www.warnermediaprivacy.com/do-not-sell/).

Always Active

Strictly Necessary Cookies

These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you, which amount to a request for services, such as setting your privacy preferences, logging in, or filling in forms.

You can set your browser to block or alert you about these cookies, but some parts of the site will not work.


[Source](https://www.cnn.com/2020/12/30/politics/us-b52s-gulf-iran/index.html)