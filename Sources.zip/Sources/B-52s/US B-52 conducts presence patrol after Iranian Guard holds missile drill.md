# US B-52 conducts ‘presence patrol’ after Iranian Guard holds missile drill

> A U.S. B-52 conducted a presence patrol in the Middle East on Sunday, a day after Iran held a drill in the Indian Ocean.

TEHRAN, Iran — Iran’s paramilitary Revolutionary Guard conducted a drill Saturday launching anti-warship ballistic missiles at a simulated target in the Indian Ocean, state television reported, amid heightened tensions over Tehran’s nuclear program and a U.S. pressure campaign against the Islamic Republic.

Footage showed two missiles smash into a target that Iranian state television described as “hypothetical hostile enemy ships” at a distance of 1,800 kilometers (1,120 miles). The report did not specify the type of missiles used.

In the first phase of the drill Friday, the Guard’s aerospace division launched surface-to-surface ballistic missiles and drones against “hypothetical enemy bases.” Iranian state television described the drill as taking place in the country’s vast central desert, the latest in a series of snap exercises called amid the escalating tensions over its nuclear program. Footage also showed four unmanned, triangle-shaped drones flying in a tight formation, smashing into targets and exploding.

Tensions between Washington and Tehran have increased amid a series of incidents stemming from President Donald Trump’s unilateral withdrawal from Iran’s nuclear deal with world powers. Amid Trump’s final days as president, Tehran has recently seized a South Korean oil tanker and begun enriching uranium closer to weapons-grade levels, while [the U.S. has sent B-52 bombers](https://www.airforcetimes.com/news/your-military/2020/12/30/air-force-b-52s-fly-from-minot-to-persian-gulf-in-round-trip-mission-to-caution-iran/), the [USS Nimitz aircraft carrier](https://www.navytimes.com/news/your-navy/2021/01/04/aircraft-carrier-nimitz-staying-in-mideast-as-iran-raises-uranium-enrichment-levels-seizes-south-korean-ship/) and [a nuclear submarine](https://www.navytimes.com/news/your-navy/2020/12/21/us-navy-announces-nuclear-submarine-passage-of-strait-of-hormuz-amid-tensions-with-iran/) into the region.

![In this image released Thursday, Jan. 14, 2021, by the Iranian Army, a missile is launched from a warship during a naval drill. (Iranian Army via AP)](https://www.armytimes.com/resizer/7toaDm5AcsS5AbB8LSZzlM-HBLQ=/500x376/filters:quality(100)/cloudfront-us-east-1.images.arcpublishing.com/mco/JG7QXGNPLFBOLA7BSWIHENDPAI.jpg)

In recent weeks, Iran has increased its military drills as the country tries to pressure President-elect Joe Biden over the nuclear accord, which he has said America could reenter.

On Sunday, the United States military announced that an Air Force B-52 completed a presence patrol in the Middle East, the second such patrol in the region this year. Bomber Task Force missions are observable ways to demonstrate the U.S. military’s continuing commitment to regional security, said U.S. Central Command’s commander, in a press release.

“Short-term deployments of strategic assets are an important part of our defensive posture in the region,” said Gen. Frank McKenzie. “The training opportunity and continued integration with regional partners improves readiness and delivers a clear and consistent message in the operational environment to both friends and potential adversaries, alike.”

### Sign up for the Army Times Daily News Roundup

Don't miss the top Army stories, delivered each afternoon

By giving us your email, you are opting in to the Army Times Daily News Roundup.

![Army Times Logo](chrome-extension://www.militarytimes.com/pb/resources/assets/svg/army-logo.svg)

Iran fired cruise missiles Thursday as part of a naval drill in the Gulf of Oman, state media reported, [under surveillance of what appeared to be a U.S. nuclear submarine](https://www.navytimes.com/news/your-navy/2021/01/15/iran-tests-missiles-under-apparent-watch-of-us-navy-nuclear-sub/). Iran’s navy did not identify the submarine at the time, but on Saturday, a news website affiliated with state television said the vessel was American. Helicopter footage of the exercise released Thursday by Iran’s navy showed what resembled an Ohio-class guided-missile submarine, the USS Georgia, which the U.S. Navy last month said had been sent to the Persian Gulf.

![In this photo released on Saturday, Jan. 16, 2021, by the Iranian Revolutionary Guard, a missile is launched in a drill in Iran. (Iranian Revolutionary Guard/Sepahnews via AP)](https://www.armytimes.com/resizer/87zByNPOPIMpML_mqxJRhW_ZPxQ=/800x0/filters:quality(100)/cloudfront-us-east-1.images.arcpublishing.com/mco/NRIGSYWQ25EOXM6KZHTWX2C2KU.jpg)

In this photo released on Saturday, Jan. 16, 2021, by the Iranian Revolutionary Guard, a missile is launched in a drill in Iran. (Iranian Revolutionary Guard/Sepahnews via AP)

Iran has missile capability of up to 2,000 kilometers (1,250 miles), far enough to reach archenemy Israel and U.S. military bases in the region. Last January, after the U.S. killed a top Iranian general in Baghdad, Tehran retaliated by firing a barrage of ballistic missiles at two Iraqi bases housing U.S. troops, resulting in brain concussion injuries to dozens of them.

Trump in 2018 unilaterally withdrew the U.S. from Iran’s nuclear deal, in which Tehran had agreed to limit its uranium enrichment in exchange for the lifting of economic sanctions. Trump cited Iran’s ballistic missile program among other issues in withdrawing from the accord.

When the U.S. then increased sanctions, Iran gradually and publicly abandoned the deal’s limits on its nuclear development.

_Military Times staff contributed to this report._


[Source](https://www.armytimes.com/news/your-military/2021/01/17/us-b-52-conducts-presence-patrol-after-iranian-guard-holds-anti-warship-ballistic-missile-drill/)