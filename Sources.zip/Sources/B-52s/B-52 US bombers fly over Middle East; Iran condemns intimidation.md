# B-52 US bombers fly over Middle East; Iran condemns intimidation

> Iranian foreign minister says US would be better off spending its military billions ‘on your taxpayers’ health.

Iranian foreign minister says the US would be better off spending its military billions ‘on your taxpayers’ health’.

The United States again flew B-52 bombers over the Middle East with Iran responding it should spend its military budget on healthcare for Americans rather than intimidation tactics.

The US Central Command (CENTCOM) said on Sunday the “presence patrols” were flown “as a key part of CENTCOM’s defensive posture”.

> .[@usairforce](https://twitter.com/usairforce?ref_src=twsrc%5Etfw) B-52H crews conduct second Middle East presence patrol of 2021 as key part of CENTCOM’s defensive posture. [@DeptofDefense](https://twitter.com/DeptofDefense?ref_src=twsrc%5Etfw) [@USAFCENT](https://twitter.com/USAFCENT?ref_src=twsrc%5Etfw) [@TeamMinot](https://twitter.com/TeamMinot?ref_src=twsrc%5Etfw) [@AirMobilityCmd](https://twitter.com/AirMobilityCmd?ref_src=twsrc%5Etfw) [@US\_Stratcom](https://twitter.com/US_Stratcom?ref_src=twsrc%5Etfw) [#B52](https://twitter.com/hashtag/B52?src=hash&ref_src=twsrc%5Etfw)[https://t.co/evxntC3GeH](https://t.co/evxntC3GeH) [pic.twitter.com/or9tKq7cPE](https://t.co/or9tKq7cPE)
> 
> — U.S. Central Command (@CENTCOM) [January 17, 2021](https://twitter.com/CENTCOM/status/1350821395673055237?ref_src=twsrc%5Etfw)

The latest military manoeuvres come as [security analysts have warned](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/news/2021/1/2/trump-may-launch-reckless-attack-iran-experts-fear) that US President Donald Trump could take military action against Iran in his final days in office.

In recent weeks, the US military has taken a series of steps designed to deter Iran while publicly emphasising that it is not planning – and has not been instructed – to take unprovoked action against Tehran.

Iranian Foreign Minister Mohammad Javad Zarif condemned the B-52 mission on Sunday, saying if the move was an attempt to intimidate Tehran, then the US would be better off spending its military billions “on your taxpayers’ health”.

“While we have not started a war in over 200 years, we don’t shy from crushing aggressors,” Zarif said on Twitter.

> .[@Potus](https://twitter.com/POTUS?ref_src=twsrc%5Etfw) : If your B-52H “Presence Patrols” are meant to intimidate or warn Iran, you should have spent those $billions on your taxpayers’ health.
> 
> While we have not started a war in over 200 years, we don’t shy from crushing aggressors. Just ask your BFFs who supported Saddam. [pic.twitter.com/3OqNVY47dW](https://t.co/3OqNVY47dW)
> 
> — Javad Zarif (@JZarif) [January 17, 2021](https://twitter.com/JZarif/status/1350850603984039940?ref_src=twsrc%5Etfw)

The latest American Middle East flyover by the aircraft capable of carrying up to 32,000kg (70,000 pounds) of weapons – including nuclear bombs – occurred a day after the Islamic Revolutionary Guard Corps tested long-range missiles and drones against land and sea targets in Iran’s fourth large-scale military show of force in two weeks.

It was the fifth B-52 operation in recent weeks and US Central Command said aircrews successfully completed the mission.

Tensions high
-------------

Tension has risen between the US and Iran following the assassination of Iranian nuclear scientist Mohsen Fakhrizadeh in Tehran in November. Iranian President Hassan Rouhani has accused Israel, a US ally in the region, of killing the scientist and vowed “strong retaliation”.

Friction also increased around the January 3 [anniversary of the assassination](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/news/2020/1/3/irans-qassem-soleimani-killed-in-us-air-raid-at-baghdad-airport) of Iran’s top general, Qaseem Soleimani, in an American drone strike in Baghdad, Iraq.

A military confrontation would severely complicate foreign policy for US President-elect Joe Biden, who intends to restart diplomatic engagement with Tehran after assuming office on Wednesday.

Biden has said he plans to rejoin the Iran nuclear deal with world powers – a landmark accord signed during President Barack Obama’s administration, which saw Tehran limit its nuclear enrichment in exchange for a lifting of international sanctions.


[Source](https://www.aljazeera.com/news/2021/1/18/b-52-us-bombers-fly-over-middle-east-iran-condemns-intimidation)