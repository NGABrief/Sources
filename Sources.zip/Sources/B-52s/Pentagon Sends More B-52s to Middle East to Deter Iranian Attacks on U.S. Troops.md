# Pentagon Sends More B-52s to Middle East to Deter Iranian Attacks on U.S. Troops

> The flights came a week after President Trump warned Tehran following rocket strikes on the U.S. Embassy in Iraq.

[Politics](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/section/politics)|Pentagon Sends More B-52s to Middle East to Deter Iranian Attacks on U.S. Troops

The flights came a week after President Trump warned Tehran following rocket strikes on the U.S. Embassy in Iraq.

![](https://static01.nyt.com/images/2020/12/31/us/politics/31DC-MILITARY/31DC-MILITARY-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

![The mission was the third time in six weeks that Air Force bombers had conducted long-range flights about 60 miles off the Iranian coast.](https://static01.nyt.com/images/2020/12/31/us/politics/31DC-MILITARY/31DC-MILITARY-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Elliott Verdier/Agence France-Presse — Getty Images

WASHINGTON — Two American B-52 bombers flew another show-of-force mission in the Persian Gulf on Wednesday, a week after President Trump [warned Iran that he would hold it accountable](https://www.nytimes.com/2020/12/23/us/politics/trump-iran.html) “if one American is killed” in rocket attacks in Iraq that the administration and military officials blamed on Tehran.

The warplanes’ 36-hour round-trip mission from Minot Air Force Base in North Dakota was the third time in six weeks that Air Force bombers had conducted long-range flights about 60 miles off the Iranian coast, moves that military officials said were intended to deter Iran from attacking American troops in the region.

The United States periodically conducts such quick demonstration missions to the Middle East and Asia to showcase American air power to allies and adversaries. But tensions have been rising in advance of the Jan. 3 anniversary of [the American drone strike that killed Maj. Gen. Qassim Suleimani](https://www.nytimes.com/2020/01/02/world/middleeast/qassem-soleimani-iraq-iran-attack.html), the commander of Iran’s elite Quds Force of the Islamic Revolutionary Guards Corps, and the Iraqi leader of an Iranian-backed militia — deaths that Iranian leaders repeatedly insist they have not yet avenged.

American intelligence analysts in recent days say they have detected Iranian air defenses, maritime forces and other security units on higher alert. But senior Defense Department officials acknowledge they cannot tell if Iran or its Shia proxies in Iraq are preparing to strike American troops or to retaliate if Mr. Trump orders a pre-emptive attack against them, [an option that aides last month talked him out of](https://www.nytimes.com/2020/11/16/us/politics/trump-iran-nuclear.html), at least for the time being.

The bomber mission on Wednesday, which included U.S. Air Force F-16 fighters, flew up the center of the Persian Gulf and was routed well outside Iranian air space. The American warplanes were in the broader gulf region for about two hours before returning home, officials said. The Air Force conducted similar B-52 missions on Nov. 21 and Dec. 10. In all three missions, there was no immediate response from Iran.

“We do not seek conflict, but no one should underestimate our ability to defend our forces or to act decisively in response to any attack,” Gen. Kenneth F. McKenzie Jr., the head of the Pentagon’s Central Command, said in statement on Wednesday.

In [a Twitter post](https://twitter.com/realDonaldTrump/status/1341862953637822468) last week that came after a meeting with senior officials at the White House, Mr. Trump said that Iran was behind rocket attacks on the American Embassy in Baghdad on Dec. 20. “Some friendly health advice to Iran,” [Mr. Trump tweeted](https://twitter.com/realDonaldTrump/status/1341862955604975617?s=20). “If one American is killed, I will hold Iran responsible. Think it over.”

Mr. Trump’s post was followed by a statement from Central Command, which called the attacks involving 21 107-millimeter rockets the largest in a decade against U.S. personnel in Iraq. Senior American military officials said on Wednesday that the rocket attacks were carried out by Iranian-backed rogue militia groups, including Kataib Hezbollah, whose leader, Abu Mahdi al-Muhandis, was killed in the Jan. 3 drone strike.

Kataib Hezbollah has denied any involvement in last week’s rocket attacks, which killed at least one Iraqi civilian and damaged the embassy compound.

Over the past year, Iranian-aligned proxies in Iraq have conducted more than 50 rocket attacks on bases where U.S. troops are housed, as well as on the American Embassy in Baghdad, and launched 90 attacks on convoys carrying supplies to American troops, according to the Pentagon.

American commanders and diplomats say the attacks are aimed at driving American troops out of Iraq, where Mr. Trump has ordered the Pentagon to draw down to 2,500 personnel by mid-January.

Tensions had been high approaching the anniversary of the killing of General Suleimani in Iraq, where the Trump administration said he was planning attacks on American forces.

Iran responded at the time with missile strikes against bases in Iraq where U.S. troops were. No one was killed and the immediate crisis subsided, although Iran has said it had not fully avenged General Suleimani’s death.

Last month, [a top Iranian scientist, Mohsen Fakhrizadeh, was killed](https://www.nytimes.com/2020/11/27/world/middleeast/iran-nuclear-scientist-killed.html) east of Tehran in a daytime strike widely believed to have been carried out by Israeli operatives. American and Israeli officials say Mr. Fakhrizadeh was considered the driving force behind what they have described as Iran’s secretive nuclear weapons program.

In the past three weeks, Central Command has dispatched the bombers, sent an extra squadron of fighter planes to Saudi Arabia, kept the aircraft carrier Nimitz in the region and publicly announced for the first time in nearly a decade that a Tomahawk-missile-firing submarine was operating.


[Source](https://www.nytimes.com/2020/12/30/us/politics/us-trump-iran.html)