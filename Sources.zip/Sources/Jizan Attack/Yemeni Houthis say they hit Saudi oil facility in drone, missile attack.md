# Yemeni Houthis say they hit Saudi oil facility in drone, missile attack

> Yemeni Houthi forces hit a large oil facility in the southern Saudi Arabian city of Jizan in drone and missile attacks overnight, a Houthi military spokesman said on Monday.

DUBAI (Reuters) - Yemeni Houthi forces hit a large oil facility in the southern Saudi Arabian city of Jizan in drone and missile attacks overnight, a Houthi military spokesman said on Monday.

The Saudi-led coalition fighting the Houthis said earlier it had intercepted and destroyed four missiles and six explosive drones fired by the Houthis over the border towards Saudi Arabia. But there was no Saudi confirmation of where they were intercepted or whether anything was hit.

Oil company Saudi Aramco operates a 400,000-barrel-per-day refinery in the Red Sea city of Jizan, which lies around 60 km (40 miles) from the Yemen border. Aramco declined to comment.

“With many drones our armed forces targeted military aircraft, pilot accommodation and Patriot systems in Khamis Mushait, and other military targets at Abha, Jizan and Najran airports,” said Yahya Sarea, a Houthi military spokesman.

“Additionally, the giant oil facility in the Jizan industrial zone. The strike was accurate.”

Khamis Mushait, Abha, Jizan and Najran are all in southwest Saudi Arabia near the Yemen border.

Cross-border attacks by the Iran-aligned Houthi movement have escalated since late May when a truce prompted by the coronavirus pandemic expired. In late June, missiles reached the Saudi capital Riyadh.

The coalition, in a statement published by Saudi state news agency SPA, did not say where the objects where intercepted but said the drones had been launched from the Houthi-controlled capital Sanaa towards Saudi Arabia.

The coalition intervened in Yemen in March 2015 after the Houthis ousted the Saudi-backed, internationally recognised government from Sanaa in late 2014.

The Houthis, who control most large urban centres, say they are fighting a corrupt system.

Houthi spokesman Sarea said the attack into Saudi was a response to coalition aggression in Yemen, citing as the most recent example an air strike on Hajjah governorate that Houthi-run Saba news said took place on Sunday and killed 10 civilians.

Humanitarian organisations Oxfam and Save the Children condemned that reported strike and the coalition on Monday said its Joint Incident Assessment Team (JIAT) would investigate it.

The United Nations has started virtual talks among the warring parties on a permanent ceasefire and confidence-building steps to restart peace negotiations. But discussions have been complicated by the surge in violence since the ceasefire expired.

The war has killed more than 100,000 people and caused what the United Nations describes as the world’s largest humanitarian crisis.

Reporting by Alaa Swilam and Maha El Dahan, additional reporting by Rania El Gamal; Writing by Lisa Barrington; Editing by Angus MacSwan


[Source](https://www.reuters.com/article/us-saudi-security-yemen/yemeni-houthis-say-they-hit-saudi-oil-facility-in-drone-missile-attack-idUSKCN24D0U6)