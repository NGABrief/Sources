# Iran Is Moving Key Facility at Nuclear Site Underground, Satellite Images Show

> In July, an explosion rocked a key Iranian nuclear facility. Iran called it sabotage and vowed to rebuild a destroyed building underground. Iran is now turning that promise into a reality, new satellite images show.

[World](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/section/world)|Iran Is Moving Key Facility at Nuclear Site Underground, Satellite Images Show

![Natanz nuclear facility. July 8, 2020.](https://static01.nyt.com/images/2020/12/08/video/08-natanz-top-circle2/08-natanz-top-circle2-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Maxar Technologies

VisUal Investigations

In July, an explosion rocked a key Iranian nuclear facility. Iran called it sabotage and vowed to rebuild a destroyed building underground. Iran is now turning that promise into a reality, new satellite images show.

Natanz nuclear facility. July 8, 2020.Credit...Maxar Technologies

The mysterious July [explosion](https://www.nytimes.com/2020/07/10/world/middleeast/iran-nuclear-trump.html) that destroyed a centrifuge assembly hall at [Iran](https://www.nytimes.com/2020/12/09/world/middleeast/iran-mohsen-fakhrizadeh-arrests.html)’s main nuclear fuel enrichment facility in Natanz was deemed by the Iranian authorities to be enemy sabotage, and provoked a defiant response: The wrecked building would be rebuilt in [“the heart of the mountains,”](https://br.reuters.com/article/iran-nuclear-natanz/iran-building-new-production-hall-for-centrifuges-in-mountains-near-natanz-idUKL8N2G540Z) the head of Iran’s Atomic Energy Organization said.

Progress on that pledge, which could shield the facility from an aerial assault or other threats, has been unclear to outside observers. But new satellite imagery is now shedding light on the Iranian plans.

The Visual Investigations team of The New York Times has tracked construction at the site using the new imagery. For the first time, new tunnel entrances for underground construction are visible under a ridge in the mountain foothills south of the Natanz facility, about 140 miles south of Tehran.

The Times worked with [Jeffrey Lewis](https://www.middlebury.edu/institute/people/jeffrey-lewis), an arms control expert at the Middlebury Institute of International Studies at Monterey in California, to interpret the new image.

“The new facility is likely to be a far more secure location for centrifuge assembly — it is located far from a road and the ridge offers significant overburden that would protect the facility from air attack,” Mr. Lewis stated in written comments.

Video

![Cinemagraph](https://static01.nyt.com/images/2020/12/08/video/newcvr-09vid-irangfx1-newconstruction/newcvr-09vid-irangfx1-newconstruction-videoSixteenByNine1050.jpg)

The Times analyzed the images with Jeffrey Lewis at the Middlebury Institute of International Studies at Monterey and identified the location of a likely new underground facility south of the Natanz nuclear site.Credit

The July explosion was not the only recent incident that appeared to have exposed major gaps in Iran’s security of its nuclear program, which the country insists is limited to peaceful purposes. In late November, a [brazen daylight attack](https://www.nytimes.com/2020/12/02/world/middleeast/iran-assassination-nuclear-scientist.html) killed Iran’s top nuclear scientist, Mohsen Fakhrizadeh.

The Morning: Make sense of the day’s news and ideas. David Leonhardt and Times journalists guide you through what’s happening — and why it matters.

Iran has blamed Israel and the United States for the Natanz explosion and Mr. Fakhrizadeh’s assassination, which were both considered serious setbacks to [Iran’s nuclear program](https://www.nytimes.com/2020/07/10/world/middleeast/iran-nuclear-trump.html).

Mr. Lewis described the clues that underground construction was underway at the site in Natanz.

“There are what appear to be two tunnel entrances on either side of a large ridge, with a pile of spoil from excavation nearby. The space between the two entrances is large enough to accommodate a facility about the same size as the centrifuge assembly building that was destroyed this summer and that Iran indicated it was rebuilding in the mountains.”

Looking at satellite images taken over several months allows for tracking changes. Even something as simple and inconspicuous as a pile of dirt is a clue.

“The major clue is the pile of spoil from the excavation that was not present in July,” Mr. Lewis said. “Iran also regraded a pair of roads on each side of the ridge leading to what appear to be tunnel entrances.”

Video

![Cinemagraph](https://static01.nyt.com/images/2020/12/08/video/newcvr-09vid-irangfx2-spoilpile/newcvr-09vid-irangfx2-spoilpile-superJumbo.jpg)

Experts pointed to a growing pile of excavation debris as one of the key clues to new underground construction at the site.Credit

Allison Puccioni, an imagery analyst affiliated with the Center for International Security and Cooperation at Stanford University, pointed out other telltale signs of excavations near the debris pile. In comments provided to the Times, Ms Puccioni said that between the debris pile and excavation site, the imagery showed “trails of excavated earth, lighter in color than the existing hard-packed road.”

A flurry of activity in Natanz captured by satellites in recent months includes the building of new roads and additional excavations, which started after the explosion. Researchers from AllSource Analysis and the Institute for Science and International Security have previously identified the area and said that [additional tunnels](https://isis-online.org/isis-reports/detail/post-script-looking-at-the-new-construction-activity-near-natanz) are being constructed, suggesting work on [an even larger underground complex](https://allsourceanalysis.com/wp-content/uploads/2020/09/SR-Natanz-Tunnel-Construction-Iran-1.pdf) is underway.

![](https://static01.nyt.com/images/2020/12/08/video/08_roadworknatanz/08_roadworknatanz-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![Road work and earth-moving vehicles outside a future tunnel entrance. Oct. 21, 2020.](https://static01.nyt.com/images/2020/12/08/video/08_roadworknatanz/08_roadworknatanz-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Maxar Technologies

The destroyed building was built in 2012 and had been used to assemble centrifuges, the machines that enrich uranium needed for peaceful purposes — and when enriched to higher levels, for bombs. The 2015 nuclear agreement between Iran and world powers halted high level enrichment, but Iran started amassing enriched uranium again after President Trump left the accord two years ago.

![](https://static01.nyt.com/images/2020/12/08/video/08-destroyednatanz/08-destroyednatanz-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![The destroyed centrifuge assembly hall at the Natanz nuclear facility. July 8, 2020.](https://static01.nyt.com/images/2020/12/08/video/08-destroyednatanz/08-destroyednatanz-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Maxar Technologies

The ability to see via satellite what Iran has done since the Natanz explosion partly reflects the quantum leap in such visual technology in the past two decades.

In 2002, analysts [revealed](https://isis-online.org/isis-reports/detail/iran-building-nuclear-fuel-cycle-facilities-international-transparency-need/8) the construction of the then secret Natanz enrichment facility using commercial high-resolution satellite imagery. [Such sharp imagery had only become available in 2000](https://archive.nytimes.com/www.nytimes.com/library/national/science/101399sci-spy-satellite.html). Back then, [the analysis required](https://www.middlebury.edu/office/deal-podcast) finding Natanz on Persian maps in the Library of Congress, faxing an order form and waiting for weeks to receive satellite imagery on a CD-ROM. Eighteen years later, even the smallest changes at a site like Natanz can be quickly tracked by analysts and journalists on their laptops.

These monitoring capabilities can create their own challenges. Frequently collected images do not show completed construction, but work in progress. Initial interpretation of the recent changes in Natanz [from October](https://twitter.com/armscontrolwonk/status/1321849319553527810) focused on a former firing range south of the main facility as the possible location for the new underground centrifuge assembly hall. However, these changes turned out to be a construction support facility used for road work and tunnel excavations.

In response to Mr. Fakhrizadeh’s assassination, Iran enacted a law last week to immediately [ramp up uranium enrichment and bar international inspectors](https://www.nytimes.com/2020/12/02/world/middleeast/iran-nuclear-enrichment-inspectors.html) by February if U.S. sanctions are not lifted. The law also calls for the [installment of advanced centrifuges at its nuclear facilities](https://www.reuters.com/article/us-iran-nuclear-law/iran-watchdog-passes-law-on-hardening-nuclear-stance-halting-u-n-inspections-idUSKBN28C2F7), including in Natanz.

[The United States may have been aware in advance](https://www.nytimes.com/2020/11/27/world/middleeast/iran-nuclear-scientist-killed.html) of the recent attacks on Iran’s nuclear infrastructure and personnel. How Iran responds to the newest attack could pose an early challenge to the incoming Biden administration, which has said it wants to rejoin the nuclear accord repudiated by Mr. Trump.


[Source](https://www.nytimes.com/2020/12/09/world/natanz-nuclear-facility-iran.html)