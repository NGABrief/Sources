# Iranian lawmakers hail AEOI's move to resume 20% uranium enrichment
![Iran Press TV](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/presstv.gif)

Iran Press TV

Tuesday, 12 January 2021 12:53 PM

The majority of Iranian lawmakers have hailed the Atomic Energy Organization of Iran (AEOI)'s move to restart the enrichment of uranium at 20-percent purity level as part of a law recently adopted by the Parliament (Majlis).

In a statement on Tuesday, 190 legislators threw their weight behind Iran's nuclear industry for its resumption of 20% uranium enrichment and called for full and precise implementation of the law designed to counter the sanctions imposed on the country, especially those by the United States.

On December 1, Iranian lawmakers overwhelmingly voted in favor of the "Strategic Action Plan to Lift Sanctions and Safeguard Interests of Iranian People," which mainly intends to counteract the unilateral sanctions imposed on Iran after US President Donald Trump on May 8, 2018 pulled his country out of a 2015 Iran nuclear deal. The bill became law after Iran's Guardian Council ratified it a day later.

According to the new law, the Iranian administration is required to suspend more commitments under the nuclear deal, officially called the Joint Comprehensive Plan of Action (JCPOA), which was inked by Iran and six major countries on July 14 that year.

The law tasked the AEOI with producing and restoring at least 120 kilograms of enriched uranium with a 20-percent purity level every year and also enriching beyond 20 percent if the country's peaceful nuclear activities demanded it, among other things.

In their statement, the MPs said the Parliament approved the strategic action plan to reiterate Iran's legitimate right to use peaceful nuclear technology and the importance of lifting all cruel sanctions against the country.

The Islamic Republic would not step back one iota from its rights, they added.

Iran on January 4 announced the beginning of the process to enrich uranium to 20 percent purity at its Fordow nuclear facility in its latest step to reciprocate the United States' unilateral move to withdraw from the JCPOA and the failure of the European signatories to fulfill their side of the deal.

Iran remained fully compliant with the JCPOA for an entire year, waiting for the co-signatories to fulfill their end of the bargain by offsetting the impacts of American bans on the Iranian economy.

In response to the US' unilateral withdrawal from the JCPOA, Tehran has so far rowed back on its nuclear commitments five times in compliance with Articles 26 and 36 of the nuclear deal, but stressed that its retaliatory measures will be reversible as soon as Europe finds practical ways to shield the mutual trade from the US sanctions.

The AEOI spokesman Behrouz Kamalvandi said on Monday that the nuclear body will implement technical aspects of the recently-approved law, adding, "We are already doing this regardless of how the executive bylaw of this law is drawn up."

<table><tbody><tr><td><p><span size="+1" color="#8C3100"><b>NEWS</b></span><span size="+1" color="#0000C6"><b>LETTER</b></span></p></td></tr><tr><td><span face="Arial, Helvetica, sans-serif" color="#FFFFFF" size="+1"><b>Join the GlobalSecurity.org mailing list</b></span></td></tr><tr><td></td></tr></tbody></table>

  

[![One Billion Americans: The Case for Thinking Bigger - by Matthew Yglesias](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/images/temp/one-billion-americans.jpg)](https://www.amazon.com/gp/product/B082ZR6827/ "One Billion Americans: The Case for Thinking Bigger - by Matthew Yglesias")


[Source](https://www.globalsecurity.org/wmd/library/news/iran/2021/iran-210112-presstv02.htm)