# Iran Says Biden Never Reached Out to Discuss Return to Nuclear Deal
![](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/sputnik.gif)

[Sputnik News](http://www.sputniknews.com/)

10:39 GMT 19.01.2021

TEHRAN (Sputnik) - Iran has received no communications from US President-elect Joe Biden pertaining to his country's potential return to the Joint Comprehensive Plan of Action (JCPOA), spokesman for the Iranian government Ali Rabiee said on Tuesday.

"We have not received any messages from the Biden team. Nevertheless, negotiations are meaningless unless we get assured that the United States acts in line with its commitments, after resuming them without any preconditions," Rabiee said at a briefing.

Iran wants the JCPOA to survive and expects the new US administration to make efforts for rebuilding trust by means of picking up the implementation of abandoned commitments under the deal, the spokesman said.

This past Saturday, Israeli media reported that Biden's team was already in talks with Tehran over the terms for Washington's return to the 2015 nuclear deal, from which it was withdrawn by outgoing US President Donald Trump in 2018.

The JCPOA was signed in 2015 by Iran, China, France, Germany, Russia, the United Kingdom, the United States and the European Union, stipulating the removal of international sanctions from Tehran in exchange for it scaling down its nuclear program.

After the United States withdrew and reinstated sanctions on Iran, the Iranian government began gradually abandoning its own commitments under the deal, specifically with regard to uranium enrichment level and provision of access to the International Atomic Energy Agency.  

Â© Sputnik

<table><tbody><tr><td><p><span size="+1" color="#8C3100"><b>NEWS</b></span><span size="+1" color="#0000C6"><b>LETTER</b></span></p></td></tr><tr><td><span face="Arial, Helvetica, sans-serif" color="#FFFFFF" size="+1"><b>Join the GlobalSecurity.org mailing list</b></span></td></tr><tr><td></td></tr></tbody></table>

  

[![One Billion Americans: The Case for Thinking Bigger - by Matthew Yglesias](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/images/temp/one-billion-americans.jpg)](https://www.amazon.com/gp/product/B082ZR6827/ "One Billion Americans: The Case for Thinking Bigger - by Matthew Yglesias")


[Source](https://www.globalsecurity.org/wmd/library/news/iran/2021/iran-210119-sputnik03.htm)