# Iran Producing Half-a-Kilo of High-Grade Uranium Fuel Per Day, Says Atomic Energy Chief
![](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/sputnik.gif)

[Sputnik News](http://www.sputniknews.com/)

James Tweedie. Sputnik International  
20:59 GMT 19.01.2021

**The UK, France and Germany issued a joint statement on Saturday condemning Iran for resuming high-grade uranium enrichment in breach of the 2015 nuclear energy deal â€” which Washington pulled out of in 2017, re-imposing sanctions on Tehran.**

Iran's nuclear power agency chief says the country is making more than a pound of top-grade uranium fuel per day.

Atomic Energy Organization of Iran head Ali Akbar Salehi said 500 grams of fuel enriched to 20 per cent content of the fissile Uranium-235 isotope was being produced daily since the the start of the month.

Iran began high-assay enrichment in early January, nearly four years after US President Donald Trump withdrew from the 2015 Joint Comprehensive Plan of Action (JCPOA) deal jointly agreed with Russia, China, Britain, France and Germany and re-imposed sanctions on Iranian oil exports.

Iranian scientists "are producing 20 grams every hour, meaning that practically, we are producing half a kilo every day," Salehi told Grand Ayatollah Ali Khamenei's website.

Salehi added that if other parties returned to the terms of the deal, "we will return to our undertakings too." Only the US has fully withdrawn from the JCPOA, although last year Secretary of State Mike Pompeo tried unsuccessfully to pressure the remaining parties to impose sanctions on Tehran for allegedly flouting its terms.

Bout on Saturday, Britain, France and Germany â€” the so-called "E3" group of the "P5+1" set of permanent UN security council members, plus Germany â€” warned Iran not to produce metallic uranium, calling the resumption of high-grade enrichment "the latest planned violation" of the JCPOA.

"Iran has no credible civilian use for uranium metal," the three European nations said in a joint statement. "The production of uranium metal has potentially grave military implications."

Enrichment to 20 per cent is far higher than the three to five per cent used in most civilian nuclear power stations â€” but way below the 90 per cent optimal level for nuclear weapons.

However, High-Assay Low-Enriched Uranium (HALEU) with up to 20 per cent U235 will be used in a new generation of nuclear reactors

, with more than 20 firms in the US alone developing them. The US Department of Energy is working to increase the supply of HALEU fuel.

HALEU is also used in fast-neutron reactors, an older technology that can potentially reduce the amount of radioactive waste produced, and also in naval reactors used on nuclear-powered ships and submarines.

Meanwhile, Iranian government spokesman Ali Rabiee scotched Israeli reports that US president-elect Joe Biden's incoming administration had already begun talks with Tehran on reviving the JCPOA, which was negotiated while he was vice-president to Barack Obama.

"We have not received any messages from the Biden team," Rabiee said, insisting that "negotiations are meaningless unless we get assured that the United States acts in line with its commitments, after resuming them without any preconditions."

Â© Sputnik

<table><tbody><tr><td><p><span size="+1" color="#8C3100"><b>NEWS</b></span><span size="+1" color="#0000C6"><b>LETTER</b></span></p></td></tr><tr><td><span face="Arial, Helvetica, sans-serif" color="#FFFFFF" size="+1"><b>Join the GlobalSecurity.org mailing list</b></span></td></tr><tr><td></td></tr></tbody></table>

  

[![One Billion Americans: The Case for Thinking Bigger - by Matthew Yglesias](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/images/temp/one-billion-americans.jpg)](https://www.amazon.com/gp/product/B082ZR6827/ "One Billion Americans: The Case for Thinking Bigger - by Matthew Yglesias")


[Source](https://www.globalsecurity.org/wmd/library/news/iran/2021/iran-210119-sputnik02.htm)