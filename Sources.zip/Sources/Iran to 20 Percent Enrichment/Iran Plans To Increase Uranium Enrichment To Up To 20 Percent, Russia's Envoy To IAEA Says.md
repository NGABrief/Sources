# Iran Plans To Increase Uranium Enrichment To Up To 20 Percent, Russia's Envoy To IAEA Says
![[ rfe/rl banner ]](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/rferl-article2.gif)

By RFE/RL January 01, 2021

Iran has said it intends to enrich uranium to up to 20 percent purity, according to Russia's ambassador to the International Atomic Energy Agency (IAEA).

Mikhail Ulyanov said on Twitter on January 1 that IAEA Director-General Rafael Grossi "reported to the (IAEA) Board of Governors ... about intention of #Tehran to start enrichment op to 20%."

A Vienna-based diplomat confirmed there had been an IAEA report to member states that included Iran's intention, but declined to elaborate, according to Reuters.

Iran currently enriches its uranium stockpile up to around 4.5 percent, which is above the 3.67 percent cap imposed by the 2015 nuclear deal but below the 90 percent purity considered weapons-grade.

Iran has gradually reduced its compliance with the accord since the United States unilaterally withdrew from the deal in 2018 and started imposing crippling sanctions on Iran.

The remaining parties to the deal said on December 21 they were preparing for a possible return of the United States to the accord after President-elect Joe Biden takes office on January 20. Biden has said he will try to rejoin the deal, which was struck when he was vice president.

Biden has suggested the United States would reenter the deal if Iran complies with the agreement, leaving other issues of concern such as Iran's ballistic missiles and support for regional proxies to "follow on" agreements.

Iran says its missile program and regional policies are off the table and has said it would come back into compliance with the deal once the United States and the three European countries that signed the deal -- Germany, France, and Britain -- fulfill their end of the agreement by providing Tehran economic relief promised under the accord.

Tehran has always denied pursuing nuclear weapons, saying its nuclear program was strictly for civilian purposes.

_With reporting by Reuters_

Source: [https://www.rferl.org/a/iran-uranium -enrichment-20-percent/31029739.html](https://www.rferl.org/a/iran-uranium-enrichment-20-percent/31029739.html)

Copyright (c) 2021. RFE/RL, Inc. Reprinted with the permission of Radio Free Europe/Radio Liberty, 1201 Connecticut Ave., N.W. Washington DC 20036.

<table><tbody><tr><td><p><span size="+1" color="#8C3100"><b>NEWS</b></span><span size="+1" color="#0000C6"><b>LETTER</b></span></p></td></tr><tr><td><span face="Arial, Helvetica, sans-serif" color="#FFFFFF" size="+1"><b>Join the GlobalSecurity.org mailing list</b></span></td></tr><tr><td></td></tr></tbody></table>

  

[![One Billion Americans: The Case for Thinking Bigger - by Matthew Yglesias](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/images/temp/one-billion-americans.jpg)](https://www.amazon.com/gp/product/B082ZR6827/ "One Billion Americans: The Case for Thinking Bigger - by Matthew Yglesias")


[Source](https://www.globalsecurity.org/wmd/library/news/iran/2021/iran-210101-rferl01.htm)