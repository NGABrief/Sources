# Iran tells IAEA it plans to enrich uranium to up to 20% at Fordow site

> Iran has told the United Nations nuclear watchdog it plans to enrich uranium to up to 20% purity, a level it achieved before its 2015 accord, at its Fordow site buried inside a mountain, the agency said on Friday.

### CCPA Right to Opt-Out of the Sale of Your Personal Information

If you are a California consumer, you have the right, at any time, to direct a business that sells your personal information to third parties to not sell your personal information. This right is referred to as the right to opt-out. You may exercise your right to opt-out of the sale of your personal information through Reuters.com by clicking [here](https://privacyportal.onetrust.com/webform/dbf5ae8a-0a6a-4f4b-b527-7f94d0de6bbc/5dc91c0f-f1b7-4b6e-9d42-76043adaf72d). You do not have to create an account to exercise this right.

Please note that opting-out may not mean you will stop seeing advertisements. Additionally, in the event you opt-out under CCPA, but do not opt out of interest-based advertising more generally, you may still receive advertisements tailored to your interests based upon your Personal Information. For more information about your rights as a California consumer and to learn more about our use of interest-based advertising and additional opt-out choices, please see our [Privacy Statement](https://www.thomsonreuters.com/en/privacy-statement.html#california).

When you visit our website, we store cookies on your browser to collect information. The information collected might relate to you, your preferences or your device, and is mostly used to make the site work as you expect it to and to provide a more personalized web experience. However, you can choose not to allow certain types of cookies, which may impact your experience of the site and the services we are able to offer. Click on the different category headings to find out more and change our default settings according to your preference. You cannot opt-out of our First Party Strictly Necessary Cookies as they are deployed in order to ensure the proper functioning of our website (such as prompting the cookie banner and remembering your settings, to log into your account, to redirect you when you log out, etc.). For more information about the First and Third Party Cookies used please follow this [link](https://www.thomsonreuters.com/en/privacy-statement.html#cookies).

### Manage Consent Preferences

Always Active

Strictly Necessary Cookies

These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms.    You can set your browser to block or alert you about these cookies, but some parts of the site will not then work. These cookies do not store any personally identifiable information.

*   ###### Functional Cookies
    
    These cookies enable the website to provide enhanced functionality and personalisation. They may be set by us or by third party providers whose services we have added to our pages.    If you do not allow these cookies then some or all of these services may not function properly.
    

Sale of Personal Data

Under the California Consumer Privacy Act, you have the right to opt-out of the sale of your personal information to third parties. These cookies collect information for analytics and to personalize your experience with targeted ads. You may exercise your right to opt out of the sale of personal information by using this toggle switch. If you opt out we will not be able to offer you personalised ads and will not hand over your personal information to any third parties. Additionally, you may contact our legal department for further clarification about your rights as a California consumer by using this Exercise My Rights link.

If you have enabled privacy controls on your browser (such as a plugin), we have to take that as a valid request to opt-out. Therefore we would not be able to track your activity through the web. This may affect our ability to personalize ads according to your preferences.

*   ###### Performance Cookies
    
    These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site.    All information these cookies collect is aggregated and therefore anonymous. If you do not allow these cookies we will not know when you have visited our site, and will not be able to monitor its performance.
    

*   ###### Targeting Cookies
    
    These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites.    They do not store directly personal information, but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.


[Source](https://www.reuters.com/article/us-iran-nuclear-iaea-idUSKBN2962JG)