# Drones used in Saudi Arabia’s Aramco attack have Iranian components: Report

> Drone components used in attacks which targeted Saudi Aramco facilities on September 14 were Iranian

Drone components used in [attacks which targeted Saudi Aramco facilities on September 14](https://english.alarabiya.net/en/News/gulf/2019/09/14/Fire-at-Saudi-Aramco-s-facility-in-Abqaiq-under-control-cause-yet-unknown.html) were Iranian-made, according to a report by Conflict Armament Research published on Wednesday.

CAR documented a component called the “vertical gyroscope” and according to UAV experts familiar with this technology, such vertical gyroscopes “have not been observed in any UAVs other than those manufactured by Iran.”

“The gyroscopes appear to be of the same make - yet not the same model - as a unit that Saudi authorities recovered following the aerial attack on the Aramco oil facility in Abqaiq, Saudi Arabia, on September 14.”

**Read:** [Pompeo blames Iran for attack on oil facilities in Saudi Arabia](https://english.alarabiya.net/en/News/gulf/2019/09/15/Pompeo-blames-Iran-for-attack-on-Saudi-oil-facilities.html)

Many countries including Saudi Arabia and the United States blamed Iran for the attack on the Aramco oil facilities which shut down more than 5% of the global oil supply for a few days. The Houthis claimed responsibility for the attacks, and Iran denied any involvement. But evidence pointed to the fact that the cruise missile and drone attack originated from the north in the direction of Iran, rather than the south in the direction of Yemen.

The Houthis have been using drones to launch dozens of attacks against Saudi Arabia, whose forces lead the Arab coalition that intervened in Yemen to re-instate the internationally recognized government of President Abd-Rabbu Mansour Hadi.

SHOW MORE

Last Update: Wednesday, 20 May 2020 KSA 10:01 - GMT 07:01


[Source](https://english.alarabiya.net/News/gulf/2020/02/19/Drones-used-in-Saudi-Arabia-s-Abqaiq-attack-have-Iranian-components-Report)