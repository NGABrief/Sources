# Two Major Saudi Oil Installations Hit by Drone Strike, and U.S. Blames Iran (Published 2019)

> Yemen’s Houthi rebels claimed responsibility. But Secretary of State Mike Pompeo accused Tehran and said the strikes were not launched from Yemen.

Video

![Video player loading](https://static01.nyt.com/images/2019/09/16/world/15saudi-1/14saudi-1-videoSixteenByNine3000.jpg)

A Saudi Aramco plant in Abqaiq, Saudi Arabia, was attacked early Saturday, one of two sites hit.CreditCredit...Hamad I Mohammed/Reuters

*   Published Sept. 14, 2019Updated Sept. 15, 2019

Drone attacks claimed by Yemen’s Houthi rebels struck two key oil installations inside Saudi Arabia on Saturday, damaging facilities that process the vast majority of the country’s crude output and raising the risk of a disruption in world oil supplies.

The attacks immediately escalated tensions in the Persian Gulf amid a standoff between the United States and Iran, even as key questions remained unanswered — where the drones were launched from, and how the Houthis managed to hit facilities deep in Saudi territory, some 500 miles from Yemeni soil.

Secretary of State Mike Pompeo [accused Iran](https://www.nytimes.com/2019/09/15/world/middleeast/iran-us-saudi-arabia-attack.html) of being behind what he called “an unprecedented attack on the world’s energy supply” and asserted that there was “no evidence the attacks came from Yemen.” He did not, however, specify an alternative launch site, and the Saudis themselves refrained from pointing the finger directly at Iran.

President Trump condemned the attack in a phone call with Saudi Crown Prince Mohammed bin Salman and offered support for “Saudi Arabia’s self defense,” the White House said in a statement, adding that the United States “remains committed to ensuring global oil markets are stable and well supplied.”

The Houthis said they had launched the aerial attacks with 10 drones, which would amount to their most audacious strike on Saudi Arabia since the kingdom intervened in Yemen’s war more than four years ago. The Saudi-led bombing campaign has devastated the impoverished country and exacerbated the world’s worst humanitarian crisis.

The Houthis are part of a regional network of militant groups aligned with and backed by Iran, Saudi Arabia’s regional rival. American and Saudi officials suspect that Iran has dispatched technicians to Yemen to train the Houthis on drone and missile technology.

United Nations [investigators have written](https://undocs.org/en/S/2019/83) that the Houthis have acquired advanced drones that could have a range of up to 930 miles. That leaves open the possibility that the drones used Saturday had flown from Houthi-controlled territory in Yemen. But they may also have been launched from another country, such as Iraq, or from inside Saudi Arabia itself.

![](https://static01.nyt.com/images/2019/09/14/world/14saudi/merlin_160746084_80a8951c-0d10-4623-9719-4dbb27b9b4fd-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image![A still image from a video obtained from social media showing smoke billowing at an Aramco facility in Abqaiq, Saudi Arabia, one of two oil processing centers struck by drones on Saturday. It was not clear how badly damaged the facilities were, but such strikes have the potential to disrupt world oil supplies.](https://static01.nyt.com/images/2019/09/14/world/14saudi/merlin_160746084_80a8951c-0d10-4623-9719-4dbb27b9b4fd-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...via Reuters

Iran’s Islamic Revolutionary Guards Corps has been training its militia proxies in the region, from Lebanon to Yemen, in more sophisticated warfare using drones, according to two people in Iran with knowledge of the programs.

In Yemen, for example, after Houthi missiles targeting Saudi Arabia were intercepted, Iran moved to train Houthis in drone technology, taking groups to Iran to master assembling, managing and repairing drones, said the people familiar with the programs.

The Houthis have attacked Saudi infrastructure before, primarily with less accurate ballistic missiles.

The targeted oil facilities can process 8.45 million barrels of crude oil a day between them, the bulk of production in Saudi Arabia, the world’s largest oil exporter. Saudi Aramco, the state-owned oil giant, said production of 5.7 million barrels a day — well over half of the nation’s overall daily output — was suspended.

It was not immediately clear how badly the facilities were damaged, but shutting them down for more than a few days would affect the global oil supply. Analysts who closely follow the Saudi oil industry said they were hearing that the impact would not be severe — perhaps only a few days’ outage, which the Saudis could cover.

“Crude prices will still rise a bit, but apparently the world economy dodged a bullet,” said Robert McNally, the president of Rapidan Energy Group, a Washington-based market research firm.

The Morning: Make sense of the day’s news and ideas. David Leonhardt and Times journalists guide you through what’s happening — and why it matters.

The Energy Department said that, if needed, the United States was ready to use its strategic oil reserves to offset any disruption in supply.

The attacks not only exposed a Saudi vulnerability in the war against the Houthis, but also demonstrated how relatively cheap it has become to stage such high-profile strikes. The drones used may have cost $15,000 or less to build, said Wim Zwijnenburg, a senior researcher on drones at [PAX](https://www.paxforpeace.nl/), a Dutch peace organization.

Iraq

Iran

Jordan

Egypt

U.A.E.

Oman

Saudi Arabia

Sudan

Yemen

Eritrea

The strikes illustrate how David-and-Goliath tactics using cheap drones are adding a new layer of volatility to the Middle East. Such attacks not only damage vital economic infrastructure, but can also increase security costs, disrupt markets and spread fear.

While the Houthis do not have significant financial resources, drones give them a way to hurt Saudi Arabia, which was the world’s third-highest spender on military equipment in 2018, investing an [estimated $67.6 billion](https://sipri.org/sites/default/files/2019-04/fs_1904_milex_2018_0.pdf).

“This has given the Saudis a challenge they can’t confront, no matter what their financial, military or intelligence capabilities are,” said Farea Al-Muslimi, co-founder of the [Sanaa Center for Strategic Studies](https://sanaacenter.org/), which focuses on Yemen.

The attacks hit deeper into Saudi territory than most previous Houthi strikes and set off blazes whose smoke could be seen from space.

The war in Yemen began in 2014, when the Houthi rebels seized control of the capital and most of Yemen’s northwest, sending the government into exile. A coalition of Arab nations led by Saudi Arabia and the United Arab Emirates, with some support from the United States, began bombing Yemen in 2015, hoping to push the Houthis back and restore the government.

Instead, the war has settled into a stalemate, and the Houthis have developed increasingly sophisticated ways of striking back at Saudi Arabia, most notably with drones. The first indications of the Houthis using drones emerged last year, and their capabilities have improved since.  

Mr. Zwijnenburg, the researcher, said the drones gave the Houthis an edge because they were cheap to produce, hard to detect and shoot down, and able to cause damage and disruption hugely disproportionate to their cost. While the Houthis’ exact capabilities are not known, they have developed over time.

The Houthis’ alliance with Iran also raises the possibility that their successes could be shared with other Iran-aligned militant groups in Iraq, Syria and Lebanon, he added.

The strike on one of the oil installations, in Abqaiq, was particularly worrying because it processes crude from several key Saudi oil fields, said Helima Croft, an analyst at RBC Capital Markets, an investment bank.

“This is the mother lode for an attack on Saudi infrastructure,” she said. “We have always been concerned about an attack on Abqaiq.”

Amy Myers Jaffe, a Middle East energy analyst at the Council on Foreign Relations, said the attacker was “knowledgeable, picking the maximum place for impact and damage.”

Rapidan Energy Group called Abqaiq by far the most important oil facility in the world.

“A successful attack on Abqaiq is about the worst thing energy security planners think about,” because the specialized equipment there would be difficult to quickly replace, said Mr. McNally, Rapidan’s president and a former White House energy adviser under President George W. Bush.

The firm estimated the Saudis have 188 million barrels of oil on hand, or enough to cover a disruption of five million barrels per day for 37 days. Mr. McNally predicted that oil traders would quickly “start doing the math,” potentially sending prices upward.

Mr. Pompeo has led the Trump administration’s “maximum pressure” campaign against Iran, trying to isolate Tehran’s cleric-run government with a rolling series of sanctions that have lashed its economy.

At the same time, Mr. Trump has said he is open to meeting with Iran’s president, Hassan Rouhani — potentially on the sidelines of the United Nations General Assembly this month — as a first step toward striking a new nuclear accord that would also stop its ballistic missiles program and support for extremist groups.

Mr. Rouhani repeated this week that he will not negotiate until the United States eases its sanctions.

![](https://static01.nyt.com/images/2019/09/14/world/14saudi-3/14saudi-3-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Image

![An undated image of the Saudi Aramco Abqaiq oil facility in eastern Saudi Arabia.](https://static01.nyt.com/images/2019/09/14/world/14saudi-3/14saudi-3-articleLarge.jpg?quality=75&auto=webp&disable=upscale)

Credit...Saudi Aramco

Mr. McNally said these attacks are “likely to put on ice” talk of easing sanctions on Iran, with the consequences depending on how closely Tehran can be linked to them.

“Forget about easing sanctions,” he said. “We are talking about a step up on geopolitical risks.”

While there were no reports of casualties, the attacks struck at the core of the Saudi economy. They came just as Aramco accelerated plans for what could be [the largest initial public offering of stock](https://www.nytimes.com/2019/09/05/business/aramco-ipo.html) in the world, an event closely watched by global investors.

The Saudi Interior Ministry reported fires at the two processing centers — in Abqaiq and also in Khurais — before dawn on Saturday, and later said they had been attacked with drones. The ministry said both fires had been “controlled and contained,” [the Saudi-owned news network Al Arabiya reported](https://english.alarabiya.net/en/News/gulf/2019/09/14/Fire-at-Saudi-Aramco-s-facility-in-Abqaiq-under-control-cause-yet-unknown.html) without any further details.

A Houthi spokesman, Brig. Gen. Yahya Sare’e, said that the group’s forces “carried out a massive offensive operation of 10 drones targeting Abqaiq and Khurais refineries.” He did not specifically say that they launched the drones from Yemen.

The conflict in Yemen has killed thousands of civilians, many of them in [Saudi airstrikes using American-made weapons](https://www.nytimes.com/interactive/2018/12/27/world/middleeast/saudi-arabia-war-tactics-yemen-humanitarian-crisis.html). It has also created an enormous humanitarian crisis with millions at risk of starvation and millions of others homeless.

[In a report](https://www.nytimes.com/2019/09/03/world/middleeast/war-crimes-yemen.html) presented to the United Nations Human Rights Council in Geneva last week, a panel of experts said both sides in the conflict were committing horrific human rights abuses, including arbitrary killings, rape and torture, with impunity. The atrocities underscored the collective failure of the international community, the panel said.

After a period of relative calm, following [a cease-fire brokered late last year](https://www.nytimes.com/2018/12/18/world/middleeast/yemen-cease-fire.html?module=inline), tensions have escalated in recent months. Houthi forces [attacked Saudi pipelines](https://www.nytimes.com/2019/05/17/world/middleeast/saudi-oil-risk.html?module=inline) and other oil infrastructure in May, temporarily halting the flow of crude oil, and in June they [struck an airport in Saudi Arabia](https://www.nytimes.com/2019/06/12/world/middleeast/saudi-airport-attack.html), wounding dozens of people.

In July, in a major blow to the Saudi-led coalition, the United Arab Emirates, which had been providing arms, money and, crucially, ground troops in Yemen, announced [a rapid pullout](https://www.nytimes.com/2019/07/11/world/middleeast/yemen-emirates-saudi-war.html) from a conflict that had become too costly. The move left diplomats and analysts [wondering whether Saudi Arabia would continue the war](https://www.nytimes.com/2019/07/18/world/middleeast/saudi-prince-yemen-emirates.html?rref=collection%2Ftimestopic%2FYemen&action=click&contentCollection=world&region=stream&module=stream_unit&version=latest&contentPlacement=10&pgtype=collection) on its own.

Although the Trump administration has been a vocal supporter of Saudi efforts to deter Iran and its allies in the region, congressional opposition to the sale of arms and the deployment of extra troops in Saudi Arabia has [limited the scope of support from the United States](https://www.nytimes.com/2019/07/18/us/politics/troops-saudi-arabia-iran.html).

Reporting was contributed by Hwaida Saad from Beirut, Lebanon, Lara Jakes from Washington, Clifford Krauss from Houston, and Farnaz Fassihi from New York.

A version of this article appears in print on Sept. 15, 2019, Section A, Page 1 of the New York edition with the headline: Saudi Oil Supply Is Put In Danger By Drone Strikes. [Order Reprints](http://www.nytreprints.com/) | [Today’s Paper](https://www.nytimes.com/section/todayspaper) | [Subscribe](https://www.nytimes.com/subscriptions/Multiproduct/lp8HYKU.html?campaignId=48JQY)


[Source](https://www.nytimes.com/2019/09/14/world/middleeast/saudi-arabia-refineries-drone-attack.html)