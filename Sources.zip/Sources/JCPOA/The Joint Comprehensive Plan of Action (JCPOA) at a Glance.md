# The Joint Comprehensive Plan of Action (JCPOA) at a Glance

> Contact: Kelsey Davenport, Director of Nonproliferation Policy, (202) 463-8270 x102

**Contact:** [Kelsey Davenport](https://www.armscontrol.org/about/dkimball), _Director of Nonproliferation Policy,_ (202) 463-8270 x102

![](https://www.armscontrol.org/files/images/JCOPA_Vienna.png "Secretary Kerry posed with his fellow E.U., P5+1, and Iranian counterparts at the Austria Center in Vienna, Austria, on July 14, 2015, before the formal announcement of the agreement concluding the Iranian nuclear negotiations. (Photo: U.S. State Department)")The Joint Comprehensive Plan of Action (JCPOA) is a detailed, 159-page agreement with five annexes reached by Iran and the P5+1 (China France, Germany, Russia, the United Kingdom, and the United States) on July 14, 2015. The nuclear deal was endorsed by UN Security Council Resolution 2231, adopted on July 20, 2015. Iran’s compliance with the nuclear-related provisions of the JCPOA will be verified by the International Atomic Energy Agency (IAEA) according to certain requirements set forth in the agreement. On May 8, 2018, President Trump announced that the United States would withdraw from the JCPOA and reinstate U.S. nuclear sanctions on the Iranian regime. 

The following is a summary of the timeline, key components, and the current status of the multi-year agreement.

**Timeline for Implementation**

*   **July 14, 2015,** **Finalization Day**: conclusion of the agreement. Finalization day triggers Iran and the United States to begin domestic review processes of the JCPOA. Iran also begins providing the IAEA with information necessary for the agency to complete its investigation into past activities related to nuclear weapons development.  
     
*   **October 18, 2015, Adoption Day:** 90 days after the passage of the UN Security Council Resolution endorsing the deal (July 20, 2015). Adoption day triggers Iran and the P5+1 to take steps (outlined below) to meet the commitments to fully implement the JCPOA.  
     
*   **January 16, 2016,** **Implementation Day**: the IAEA certifies that Iran has taken the key steps to restrict its nuclear program and has put in place increased monitoring. The IAEA's report on implementation day triggers U.S., EU, and UN sanctions relief.  
     
*   **October 2023, Transition Day:** Eight years after adoption day (or the IAEA reaching its broader conclusion on Iran's nuclear program, whichever is sooner). Adoption day triggers the UN to lift missile restrictions, Iran to seek ratification of its additional protocol, the EU to terminate all remaining nuclear sanctions, United States to remove certain entities from the sanctioned list, and the United States to seek legislative termination of certain sanctions.  
     
*   **October 2025, Termination Day:** Ten years after adoption day. Termination day terminates Resolution 2231 and the Security Council closes Iran's nuclear file.

[![](https://www.armscontrol.org/files/images/Pg_34.png)](https://www.armscontrol.org/files/images/Pg_34.png)

**Violations of the JCPOA to Date**

Despite Iran’s verified compliance with the deal, the United States [unilaterally withdrew](https://www.whitehouse.gov/briefings-statements/president-donald-j-trump-ending-united-states-participation-unacceptable-iran-deal/) from the JCPOA on May 8, 2018, and subsequently re-imposed all U.S. sanctions on Iran lifted by the accord.

One year later, the United States further [announced](https://www.armscontrol.org/blog/2019-05-07/understanding-us-moves-jcpoa-nonproliferation-project-waivers) the termination of designated sanctions waivers for cooperative nuclear projects detailed in the JCPOA, including the transfer of enriched uranium out of Iran, the transfer and storage of heavy water outside of Iran, and the construction of additional reactor units at the Bushehr nuclear reactor. The Trump administration pledged at that time to extend (for 90 days) several of the waivers prescribed by the nuclear deal to allow certain nuclear cooperation projects in Iran to proceed, including waivers for the Arak reactor conversion, the Fordow facility conversion, the Bushehr reactor and the Tehran research reactor. However, the Trump administration has since terminated all of the waivers for cooperative nuclear projects, except for operation of the Bushehr power plant.

Iran began to incrementally violate the agreement in May 2019. Tehran tied its decision to breach the JCPOA’s limits to the deal’s failure to deliver sanctions relief envisioned by the accord. Iran is still a JCPOA participant and says it will return to compliance with the accord if its demands on sanctions relief are met.

Below is a summary of Iran’s breaches of the accord as well as additional steps taken by the Trump administration to undermine the JCPOA since the United States formally withdrew from the deal.

*   **First Breach – May 8, 2019**: Iran [announced](https://www.armscontrol.org/blog/2019-05-10/iran-announces-countermoves-nuclear-deal-p41-iran-nuclear-deal-alert) it would no longer be bound by limits on heavy water and enriched uranium stockpiles. The JCPOA prohibits Iran’s stockpile from exceeding 130 metric tons of heavy water and 300 kilograms of uranium hexafluoride gas (UF6) enriched to 3.67 percent uranium-235. The IAEA verified that Iran breached the uranium stockpile limit [July 1, 2019](https://www.iaea.org/sites/default/files/19/07/govinf2019-8.pdf), and the heavy water limit on [Nov. 17, 2019](https://www.iaea.org/sites/default/files/19/11/govinf2019-17.pdf). Since that time, Iran continues to produce uranium in excess of the stockpile cap, but its heavy water stockpile has fluctuated and, at times, returned to below the 130-ton limit.
    
*   **Second Breach – July 7, 2019**: Iran [announced](https://www.nytimes.com/2019/07/07/world/middleeast/iran-nuclear-limits-breach.html) it would exceed the 3.67 percent uranium-235 enrichment limit designated by the JCPOA. On July 8, 2019, Iran reported it had begun enriching uranium to 4.5 percent uranium-235. Iran’s breach of the 3.67 percent limit was verified by the IAEA on [July 8, 2019](https://www.iaea.org/sites/default/files/19/07/govinf2019-9.pdf), and since then, Iran has continued to enrich uranium up to 4.5 percent.
    
*   **Third Breach – September 5, 2019**: Iran [announced](http://president.ir/en/111155) it would cease to honor the limitations on research and development of advanced centrifuges imposed by the JCPOA. On Sept. 7, 2019, the IAEA verified that Iran had begun to install advanced centrifuges in excess of the amount permitted by the JCPOA. On [Sept. 25, 2019](https://www.iaea.org/sites/default/files/19/11/govinf2019-12.pdf), the IAEA reported that Iran had begun to accumulate enriched uranium from advanced machines. Iran continues to install advanced centrifuges and to produce enriched uranium using those new machines, both in violation of the accord.
    
*   **Fourth Breach – November 5, 2019**: Iran [announced](https://www.aljazeera.com/news/2019/11/05/irans-rouhani-announces-another-step-away-from-2015-nuclear-deal/) that technicians would begin enriching uranium up to 4.5 percent uranium-235 at the Fordow enrichment facility. Under the JCPOA, Iran is prohibited from enriching uranium at Fordow for 15 years.. The IAEA verified on Nov. 6, 2019, the transfer of uranium gas from Natanz to Fordow. The IAEA confirmed the resumption of uranium enrichment at Fordow on [Nov. 9, 2019](https://www.iaea.org/sites/default/files/19/11/gov2019-55.pdf). In response, the Trump administration [announced](https://www.reuters.com/article/us-usa-iran/u-s-to-no-longer-waive-sanctions-on-iranian-nuclear-site-watching-irans-protests-pompeo-idUSKBN1XS2DG) on Nov. 18, 2019, that it would no longer waive sanctions related to Iran’s Fordow facility. That waiver expired Dec. 15, 2019.
    
*   **Fifth Breach – January 5, 2020**: Iran [announced](https://twitter.com/JZarif/status/1213900666164432900) that it would no longer be bound by any operational limitations of the JCPOA, but that it would maintain compliance with its safeguards obligations under the deal. Since then, Iran has not taken any additional observed steps in violation of the deal, according to IAEA reports.
    

Secretary of State Michael Pompeo [announced](https://www.state.gov/keeping-the-world-safe-from-irans-nuclear-program/) May 27, 2020, that the United States would terminate all remaining sanctions waivers allowing for nonproliferation cooperation projects in Iran. Pompeo said the waivers covering the conversion of the Arak reactor, the provision of enriched fuel for the Tehran Research Reactor, and the export of Iran’s spent fuel would expire after a sixty-day wind down period but clarified that the waiver covering international support for Iran’s Bushehr reactor would remain in place. Those waivers expired in late-July, 2020.

**US Snapback Attempt**

On Aug. 20, 2020, Pompeo [delivered](https://www.npr.org/2020/08/20/904475552/pompeo-tries-starting-snapback-clock-to-restore-sanctions-against-iran-by-u-n) a letter to UN Secretary-General Antonio Guterres and to Indonesia’s Ambassador to the UN, currently presiding over the Security Council, calling for the introduction of a resolution to continue the lifting of sanctions on Iran.

In doing so, Pompeo cited the text of Security Council Resolution 2231, which endorses the deal and outlines a process to reimpose sanctions on Iran.. That process, which was drafted to ensure that no veto-wielding Security Council member could block the re-imposition of sanctions, grants named JCPOA participants the right to call for a resolution to continue the lifting of sanctions on Iran which could subsequently be vetoed by the United States, France, Russia, China, or the United Kingdom. Resolution 2231 still names the United States as a participant because the text was never amended to reflect U.S. withdrawal from the deal in May 2018.

Resolution 2231 stipulates that if a vote on a resolution to continue the sanctions lifting is not called for within 30 days of notification, then all UN sanctions lifted on Iran per the nuclear deal are automatically re-imposed.  
Pompeo [announced](https://www.state.gov/the-return-of-un-sanctions-on-the-islamic-republic-of-iran/) on Sept. 19, 2020, that all UN sanctions lifted in accordance with the nuclear deal were re-imposed on Iran. The Trump administration subsequently threatened to penalize any individuals or states that failed to enforce the re-imposition of sanctions. However, UN Secretary-General Guterres and many UN member states—including the remaining parties to the JCPOA—[dismissed](https://www.usnews.com/news/world/articles/2020-09-19/un-chief-says-no-action-on-un-iran-sanctions-due-to-uncertainty) the US call to re-impose sanctions, citing that the United States withdrew from the JCPOA in 2018 and is therefore not entitled to trigger the reimposition of UN sanctions on Iran.


[Source](https://www.armscontrol.org/factsheets/JCPOA-at-a-glance)