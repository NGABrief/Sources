# What is the Iran nuclear deal? | DW | 06.10.2017

> The Iran nuclear deal was a historic diplomatic achievement to prevent Tehran's pathway to a bomb. Here's our brief breakdown of what you need to know about the deal.

The Iran nuclear deal was a historic diplomatic achievement to prevent Tehran's pathway to a bomb. Here's our brief breakdown of what you need to know about the deal.

The Iran nuclear deal, known as the [Joint Comprehensive Plan of Action (JCPOA),](https://www.state.gov/documents/organization/245317.pdf) was reached in July 2015 between Iran and international powers after nearly 20 months of negotiations.

Under the JCPOA, Iran and the United States, Germany, Britain, China, Russia and France (known as the P5+1), as well as the European Union, agreed to lift crippling international sanctions related to Iran's nuclear program in exchange for Tehran dismantling it.

The JCPOA went into effect in October 2015, followed in January 2016 by implementation the day after the International Atomic Energy Agency (IAEA) verified Iran's nuclear program to be peaceful.

That led to the lifting of UN and national nuclear-related sanctions on Iran, including those on finance, trade and energy. As part of the deal, tens of billions of dollars of Iran's frozen assets were released.

Sanctions can be "snapped back" if Iran violates the deal. The IAEA, which monitors the deal, has [repeatedly confirmed Iran is complying](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/en/un-gives-iran-all-clear-on-2015-nuclear-deal/a-40315089) with all aspects of the JCPOA.

_Read:_ [What are Trump's objections to the Iran nuclear deal?](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/en/what-are-donald-trumps-objections-to-the-iran-nuclear-deal/a-40601669)

The JCPOA allows Iran to pursue a peaceful nuclear program for commercial, medical and industrial purposes in line with international non-proliferation standards.

Importantly, the JCPOA is strictly about Iran's nuclear program. It does not address other issues such as its ballistic missile program, human rights abuses, support for terrorist organizations and alleged "destabilization" activities in the Middle East.

The EU and the United States have separate sanctions and trade restrictions related to these issues. [A separate UN Security Council resolution](http://www.un.org/en/sc/2231/restrictions-ballistic.shtml) addresses Iran's ballistic missile program.

At the time of the deal, US intelligence estimated it would take Iran as little as three months to produce enough fissile material for one nuclear weapon.

Through the JCPOA, the potential pathways for Iran to develop a nuclear weapon were blocked.

 [![Infografik Iran's nuclear facilities covered under the nuclear deal Iran's nuclear facilities covered under the nuclear deal ](https://static.dw.com/image/40849023_401.png "Infografik Iran's nuclear facilities covered under the nuclear deal Iran's nuclear facilities covered under the nuclear deal ")](#) 

**The uranium pathways**

One pathway was through a uranium bomb. Iran has two uranium enrichment facilities suitable for this: at Natanz and Fordow.

Under the JCPOA, no enrichment is allowed at Fordow for 15 years.

For 10 years, the Natanz facility is allowed about 5,000 centrifuges compared to about 20,000 before the nuclear deal. The centrifuges that are allowed are the oldest and least efficient.

Iran also reduced its stockpile of uranium by 98 percent to 300 kilograms for 15 years. Before the deal, Iran had enough uranium to build ten nuclear bombs – 300 kilograms is not enough to build one bomb.

Iran also committed to keep uranium enrichment at 3.67 percent, far below the 90 percent enrichment level needed to make a nuclear weapon.  The low-enriched uranium was shipped to Russia.

[![Iran also has a Russian built nuclear power plant at Bushehr. ](https://static.dw.com/image/19451398_401.jpg "Iran also has a Russian built nuclear power plant at Bushehr. ")](#)

Iran also has a Russian-built nuclear power plant at Bushehr.

**The plutonium pathway**

The third pathway to a nuclear bomb was through weapons-grade plutonium at the Arak heavy water nuclear reactor.

Under the JCPOA, the heavy water reactor at Arak was redesigned so that it cannot produce weapons-grade plutonium. Also, spent fuel rods that could be used to develop a nuclear bomb are sent out of the country.

For 15 years, Iran will not be allowed to build a heavy water reactor or accumulate excess heavy water.

**Covert pathway**

The JCPOA includes a [robust monitoring, verification and inspection regime carried out by the IAEA.](https://www.iaea.org/sites/default/files/infcirc214a1.pdf) The inspections regime allows the IAEA to monitor declared nuclear facilities, storage facilities and supply chains.

This allows international inspectors to identify if Iran is covertly developing nuclear weapons at undeclared sites or military facilities.

If the IAEA suspects covert activity, an additional protocol to the JCPOA [allows inspectors access to any site, including military facilities.](chrome-extension://cjedbglnccaioiolemnfhjncicchinao/en/us-wants-atomic-agency-to-inspect-irans-military-facilities/a-40211979)

This requires that Iran allow access to any site within 24 days if a majority of signatories to the accord agree.


[Source](https://www.dw.com/en/what-is-the-iran-nuclear-deal/a-40848713)